"""
UNIFIED TRADING SYSTEM for AdaptiveTrendSurferX2
Supports Coinbase and BitMart with IDENTICAL LOGIC
Uses config.json for all settings
"""

import csv
import json
import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, timezone
from pathlib import Path
import logging
import os
from AdaptiveTrendSurferX2 import AdaptiveTrendSurferX2

# ---------- Setup Logging ----------
def setup_logging(log_type="main"):
    """Setup logging configuration"""
    os.makedirs('logs', exist_ok=True)
    
    log_file = f'logs/{log_type}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'
    
    logger = logging.getLogger(log_type)
    logger.setLevel(logging.INFO)
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # File handler
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(console_handler)
    
    return logger, log_file

# ---------- Configuration ----------
def load_config(config_path="config.json"):
    """Load configuration from JSON file"""
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
        print("✅ Configuration loaded successfully")
        return config
    except Exception as e:
        print(f"❌ Error loading config: {e}")
        raise

def parse_symbols(symbols_config, exchange="coinbase"):
    """Parse symbols from config with exchange-specific formatting"""
    if isinstance(symbols_config, str):
        symbols = [s.strip() for s in symbols_config.split(",") if s.strip()]
    elif isinstance(symbols_config, list):
        symbols = symbols_config
    else:
        symbols = [str(symbols_config)]
    
    # Format symbols based on exchange
    formatted_symbols = []
    for symbol in symbols:
        if exchange == "bitmart":
            # BitMart format: BTC_USDT
            symbol = symbol.replace('-', '_')
            if '_' not in symbol:
                symbol = f"{symbol}_USDT"
        else:  # coinbase
            # Coinbase format: BTC-USD
            symbol = symbol.replace('_', '-')
            if '-' not in symbol:
                symbol = f"{symbol}-USD"
        
        formatted_symbols.append(symbol.upper())
    
    return formatted_symbols

# ---------- Exchange Selection ----------
def select_exchange():
    """Let user select exchange"""
    print("\n" + "="*50)
    print("EXCHANGE SELECTION")
    print("="*50)
    print("1. Coinbase")
    print("2. BitMart")
    print("3. Exit Program")
    
    while True:
        choice = input("\nSelect exchange (1-3): ").strip()
        
        if choice == "1":
            return "coinbase"
        elif choice == "2":
            return "bitmart"
        elif choice == "3":
            return "exit"
        else:
            print("❌ Invalid choice! Please select 1-3.")

def select_mode():
    """Let user select mode"""
    print("\n" + "="*50)
    print("MODE SELECTION")
    print("="*50)
    print("1. Live Trading")
    print("2. Backtest")
    print("3. Download Data")
    print("4. Show Data")
    print("5. Return to Exchange Selection")
    
    while True:
        choice = input("\nSelect mode (1-5): ").strip()
        
        if choice in ["1", "2", "3", "4", "5"]:
            return choice
        else:
            print("❌ Invalid choice! Please select 1-5.")

# ---------- Exchange-Specific Functions ----------
def resolution_to_granularity(res: str, exchange: str = "coinbase") -> str:
    """Convert resolution to exchange-specific granularity"""
    r = res.lower()
    
    if exchange == "coinbase":
        if r in ("minute", "1min", "m1"): return "ONE_MINUTE"
        if r in ("5min", "m5"): return "FIVE_MINUTE"
        if r in ("15min", "m15"): return "FIFTEEN_MINUTE"
        if r in ("hour", "hr", "h1", "60min"): return "ONE_HOUR"
        if r in ("6hour", "h6"): return "SIX_HOUR"
        if r in ("daily", "day", "1d", "d"): return "ONE_DAY"
        raise ValueError(f"Unsupported RESOLUTION '{res}' for Coinbase.")
    
    elif exchange == "bitmart":
        # ALL OFFICIAL BITMART TIMEFRAMES
        if r in ("minute", "min", "m1", "1min"): return "1m"
        if r in ("3min", "m3"): return "3m"
        if r in ("4min", "m4"): return "4m"  # Added 4min support
        if r in ("5min", "m5"): return "5m"
        if r in ("15min", "m15"): return "15m"
        if r in ("30min", "m30"): return "30m"
        if r in ("36min", "m36"): return "36m"  # Added 36min support
        if r in ("78min", "m78"): return "78m"  # Added 78min support
        if r in ("hour", "hr", "h1", "60min", "1hour"): return "1h"
        if r in ("2hour", "h2"): return "2h"
        if r in ("4hour", "h4"): return "4h"
        if r in ("6hour", "h6"): return "6h"
        if r in ("12hour", "h12"): return "12h"
        if r in ("daily", "day", "1d", "d"): return "1d"
        if r in ("3day", "3d"): return "3d"
        if r in ("weekly", "week", "1w"): return "1w"
        if r in ("month", "monthly", "1mn"): return "1mn"
        raise ValueError(f"Unsupported RESOLUTION '{res}' for BitMart. Use: 1min, 3min, 4min, 5min, 15min, 30min, 36min, 78min, 1hour, 2hour, 4hour, 6hour, 12hour, 1day, 3day, 1week, 1month")
        
    else:
        raise ValueError(f"Unsupported exchange: {exchange}")

def get_exchange_client(exchange, config):
    """Get exchange-specific client"""
    if exchange == "coinbase":
        try:
            from fetch_coinbase import build_rest_client
            client = build_rest_client(verbose=False)
            print("✅ Coinbase API connected")
            return client
        except Exception as e:
            print(f"❌ Coinbase API connection failed: {e}")
            return None
    
    elif exchange == "bitmart":
        try:
            from bitmart_api import BitMartRESTClient
            client = BitMartRESTClient()
            
            # Test connection
            symbols = client.get_all_symbols()
            if symbols:
                print(f"✅ BitMart API connected - {len(symbols)} symbols available")
                return client
            else:
                print("❌ BitMart connection test failed")
                return None
        except Exception as e:
            print(f"❌ BitMart API connection failed: {e}")
            return None
    
    return None

def fetch_ohlcv_live(client, exchange, symbol, granularity, start_dt, end_dt):
    """Fetch OHLCV data from exchange - UNIFIED INTERFACE"""
    if exchange == "coinbase":
        return fetch_ohlcv_coinbase_live(client, symbol, granularity, start_dt, end_dt)
    elif exchange == "bitmart":
        return fetch_ohlcv_bitmart_live(client, symbol, granularity, start_dt, end_dt)
    else:
        return []

def fetch_ohlcv_coinbase_live(client, symbol: str, granularity: str, start_dt: datetime, end_dt: datetime):
    """Fetch OHLCV data from Coinbase"""
    try:
        start_ts = str(int(start_dt.timestamp()))
        end_ts = str(int(end_dt.timestamp()))
        
        print(f"   📡 Coinbase: Fetching {symbol} from {start_dt.strftime('%Y-%m-%d %H:%M:%S UTC')} to {end_dt.strftime('%Y-%m-%d %H:%M:%S UTC')}")
        
        response = client.get_candles(
            product_id=symbol,
            start=start_ts,
            end=end_ts,
            granularity=granularity
        )
        
        candles_data = []
        if hasattr(response, 'candles') and response.candles:
            candles_data = response.candles
        elif hasattr(response, 'data') and response.data:
            candles_data = response.data
        
        if not candles_data:
            print(f"   📭 No data returned for {symbol}")
            return []
        
        processed_candles = []
        
        for candle in candles_data:
            if hasattr(candle, 'to_dict'):
                candle_dict = candle.to_dict()
            elif hasattr(candle, '__dict__'):
                candle_dict = candle.__dict__
            else:
                candle_dict = candle
            
            open_price = float(candle_dict.get('open', 0))
            high = float(candle_dict.get('high', 0))
            low = float(candle_dict.get('low', 0))
            close = float(candle_dict.get('close', 0))
            volume = float(candle_dict.get('volume', 0))
            
            timestamp_sec = int(candle_dict.get('start', 0))
            if timestamp_sec == 0:
                timestamp_sec = int(candle_dict.get('time', 0))
            
            candle_dt = datetime.fromtimestamp(timestamp_sec, tz=timezone.utc)
            
            if open_price <= 0 or high < low or high <= 0 or low <= 0:
                continue
            
            processed_candles.append((candle_dt, open_price, high, low, close, volume))
        
        processed_candles.sort(key=lambda x: x[0])
        
        print(f"   ✅ Retrieved {len(processed_candles)} candles for {symbol}")
        
        if processed_candles:
            first_dt = processed_candles[0][0]
            last_dt = processed_candles[-1][0]
            print(f"   📅 Data range: {first_dt.strftime('%H:%M:%S UTC')} to {last_dt.strftime('%H:%M:%S UTC')}")
        
        return processed_candles
                
    except Exception as e:
        print(f"   ❌ Error fetching {symbol}: {e}")
        return []

def fetch_ohlcv_bitmart_live(client, symbol: str, interval: str, start_dt: datetime, end_dt: datetime):
    """Fetch OHLCV data from BitMart - MATCHING COINBASE FORMAT"""
    try:
        # Convert symbol format
        bitmart_symbol = symbol.replace('-', '_').upper()
        
        print(f"   📡 BitMart: Fetching {bitmart_symbol} from {start_dt.strftime('%Y-%m-%d %H:%M:%S UTC')} to {end_dt.strftime('%Y-%m-%d %H:%M:%S UTC')}")
        
        # Convert interval to BitMart timeframe
        # Map from simple format to BitMart format
        timeframe_map = {
            '1min': '1min', '3min': '3min', '4min': '4min', '5min': '5min', 
            '15min': '15min', '30min': '30min', '36min': '36min', '78min': '78min',
            '1hour': '1hour', '2hour': '2hour', '4hour': '4hour', '6hour': '6hour', 
            '12hour': '12hour', '1day': '1day', '3day': '3day', '1week': '1week', 
            '1month': '1month'
        }
        
        # If interval is in Coinbase format (like "ONE_MINUTE"), convert first
        if interval in ["ONE_MINUTE", "FIVE_MINUTE", "FIFTEEN_MINUTE", "ONE_HOUR", "SIX_HOUR", "ONE_DAY"]:
            coinbase_to_simple = {
                "ONE_MINUTE": "1min",
                "FIVE_MINUTE": "5min", 
                "FIFTEEN_MINUTE": "15min",
                "ONE_HOUR": "1hour",
                "SIX_HOUR": "6hour",
                "ONE_DAY": "1day"
            }
            simple_res = coinbase_to_simple.get(interval, "5min")
            bitmart_timeframe = timeframe_map.get(simple_res, "5min")
        else:
            # Already in simple format
            bitmart_timeframe = timeframe_map.get(interval.lower(), "5min")
        
        # Calculate limit based on time range
        interval_seconds = {
            '1min': 60, '3min': 180, '4min': 240, '5min': 300, '15min': 900, 
            '30min': 1800, '36min': 2160, '78min': 4680,
            '1hour': 3600, '2hour': 7200, '4hour': 14400, '6hour': 21600, '12hour': 43200,
            '1day': 86400, '3day': 259200, '1week': 604800, '1month': 2592000
        }.get(bitmart_timeframe, 300)
        
        total_seconds = int((end_dt - start_dt).total_seconds())
        limit = min(int(total_seconds / interval_seconds) + 10, 200)
        
        # ✅ FIXED: Use existing get_klines() method, not get_klines_as_tuples()
        raw_candles = client.get_klines(
            symbol=bitmart_symbol,
            timeframe=bitmart_timeframe,
            limit=limit,
            before=int(end_dt.timestamp())  # Use before parameter
        )
        
        # Convert to tuple format matching Coinbase
        candles = []
        for candle_dict in raw_candles:
            candles.append((
                candle_dict['timestamp'],  # datetime
                candle_dict['open'],       # open
                candle_dict['high'],       # high
                candle_dict['low'],        # low
                candle_dict['close'],      # close
                candle_dict['volume']      # volume
            ))
        
        if not candles:
            print(f"   📭 No data returned for {bitmart_symbol}")
            return []
        
        # Filter by time range
        processed_candles = []
        for candle in candles:
            candle_dt = candle[0]  # timestamp is first element in tuple
            
            # Filter by time range
            if start_dt <= candle_dt <= end_dt:
                processed_candles.append(candle)
        
        print(f"   ✅ Retrieved {len(processed_candles)} candles for {bitmart_symbol}")
        
        if processed_candles:
            first_dt = processed_candles[0][0]
            last_dt = processed_candles[-1][0]
            print(f"   📅 Data range: {first_dt.strftime('%H:%M:%S UTC')} to {last_dt.strftime('%H:%M:%S UTC')}")
        
        return processed_candles
        
    except Exception as e:
        print(f"   ❌ Error fetching {symbol}: {e}")
        import traceback
        traceback.print_exc()
        return []
    
# ---------- Strategy Initialization ----------
def initialize_strategy(symbol, config, exchange):
    """Initialize strategy for trading"""
    try:
        print(f"🔄 Initializing {exchange} strategy for {symbol}...")
        
        symbol_config = config.copy()
        symbol_config['symbol'] = symbol.upper()
        symbol_config['exchange'] = exchange
        
        strategy = AdaptiveTrendSurferX2(symbol_config)
        
        print(f"   📊 {symbol} Strategy Ready:")
        print(f"      TSI: {getattr(strategy, 'm_tsi', 0):.4f}")
        print(f"      Position: {getattr(strategy, 'positions', 0)}")
        
        return strategy
        
    except Exception as e:
        print(f"❌ Error initializing strategy for {symbol}: {e}")
        return None

# ---------- Trading Execution ----------
def execute_trade(client, exchange, symbol, side, quantity, price=None, order_type="market"):
    """Execute a real trade on the exchange"""
    try:
        print(f"\n🚀 EXECUTING {side.upper()} ORDER")
        print(f"   Exchange: {exchange.upper()}")
        print(f"   Symbol: {symbol}")
        print(f"   Quantity: {quantity}")
        print(f"   Type: {order_type}")
        if price:
            print(f"   Price: ${price:.2f}")
        
        if exchange == "coinbase":
            # Coinbase order execution
            if order_type.lower() == "market":
                if side.lower() == "buy":
                    order = client.market_order_buy(
                        product_id=symbol,
                        quote_size=str(quantity)
                    )
                else:  # sell
                    order = client.market_order_sell(
                        product_id=symbol,
                        base_size=str(quantity)
                    )
            else:  # limit order
                if side.lower() == "buy":
                    order = client.limit_order_gtc_buy(
                        product_id=symbol,
                        base_size=str(quantity),
                        limit_price=str(price)
                    )
                else:  # sell
                    order = client.limit_order_gtc_sell(
                        product_id=symbol,
                        base_size=str(quantity),
                        limit_price=str(price)
                    )
            
            print(f"   ✅ Order placed: {order.get('order_id', 'Unknown')}")
            return order
            
        elif exchange == "bitmart":
            # BitMart order execution
            order = client.place_order(
                symbol=symbol,
                side=side,
                order_type=order_type,
                size=quantity,
                price=price
            )
            
            if order:
                print(f"   ✅ Order placed: {order.get('order_id', 'Unknown')}")
                return order
            else:
                print(f"   ❌ Order failed")
                return None
        
        return None
        
    except Exception as e:
        print(f"❌ Trade execution failed: {e}")
        return None

def save_trading_results(strategy, symbol, exchange, reason=""):
    """Save trading results"""
    try:
        os.makedirs('results/trades', exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        date_str = datetime.now().strftime("%Y%m%d")
        
        # Save trades
        if hasattr(strategy, 'trades') and strategy.trades:
            trades_df = pd.DataFrame(strategy.trades)
            trades_file = f"results/trades/{exchange}_{symbol}_{date_str}.csv"
            
            if os.path.exists(trades_file):
                existing_df = pd.read_csv(trades_file)
                combined_df = pd.concat([existing_df, trades_df]).drop_duplicates(subset=['trade_id'], keep='last')
                combined_df.to_csv(trades_file, index=False)
            else:
                trades_df.to_csv(trades_file, index=False)
            
            print(f"💾 Trades saved: {trades_file} ({len(strategy.trades)} total)")
        
        # Save current state
        state_file = f"results/trades/{exchange}_{symbol}_state.json"
        state_data = {
            'timestamp': datetime.now().isoformat(),
            'symbol': symbol,
            'exchange': exchange,
            'positions': getattr(strategy, 'positions', 0),
            'entry_price': getattr(strategy, 'entry_price', 0),
            'cash': getattr(strategy, 'cash', getattr(strategy, 'initial_cash', 0)),
            'tsi': getattr(strategy, 'm_tsi', 0),
            'tsi_ma': getattr(strategy, 'm_tsiMA', 0),
            'total_trades': len(strategy.trades) if hasattr(strategy, 'trades') else 0,
            'save_reason': reason
        }
        
        with open(state_file, 'w') as f:
            json.dump(state_data, f, indent=2, default=str)
            
        return True
        
    except Exception as e:
        print(f"❌ Error saving results: {e}")
        return False

# ---------- Live Trading ----------
def run_live_mode(exchange: str):
    """Run live trading for selected exchange"""
    logger, log_file = setup_logging(f"live_{exchange}")
    
    try:
        print(f"\n🚀 LIVE TRADING MODE - {exchange.upper()}")
        print("="*50)
        
        config = load_config("config.json")
        
        # Get symbols for this exchange
        if exchange == "bitmart":
            symbols = parse_symbols(config.get('BITMART_SYMBOLS', config.get('SYMBOLS', ['BTC_USDT'])), exchange)
        else:
            symbols = parse_symbols(config.get('COINBASE_SYMBOLS', config.get('SYMBOLS', ['BTC-USD'])), exchange)
        
        # Get resolution from config
        resolution = config.get('RESOLUTION', '5min')
        granularity = resolution_to_granularity(resolution, exchange)
        check_interval = config.get('LIVE_CHECK_INTERVAL_SECONDS', 60)
        
        print(f"Exchange: {exchange.upper()}")
        print(f"Trading Symbols: {', '.join(symbols)}")
        print(f"Resolution from config: {resolution}")
        print(f"Granularity: {granularity}")
        print(f"Check Interval: {check_interval}s")
        print(f"Initial Cash: ${config.get('initial_cash', 100000):,.2f}")
        
        # Ask for trading confirmation
        print("\n⚠️  LIVE TRADING WARNING")
        print("   Real money will be used for trading!")
        confirm = input("   Type 'YES' to confirm live trading: ").strip()
        
        if confirm != "YES":
            print("❌ Live trading cancelled")
            return
        
        # Initialize exchange client
        client = get_exchange_client(exchange, config)
        if not client:
            return
        
        # Initialize strategies
        strategies = {}
        for symbol in symbols:
            strategy = initialize_strategy(symbol, config, exchange)
            if strategy:
                strategies[symbol] = strategy
                print(f"✅ Strategy initialized for {symbol}")
            else:
                print(f"❌ Failed to initialize strategy for {symbol}")
        
        if not strategies:
            print("❌ No strategies initialized successfully")
            return
        
        print(f"\n🎯 LIVE TRADING STARTED")
        print(f"   Exchange: {exchange.upper()}")
        print(f"   Active Symbols: {', '.join(strategies.keys())}")
        print(f"   Log File: {log_file}")
        print("   Press Ctrl+C to stop\n")
        
        last_processed = {symbol: None for symbol in strategies.keys()}
        
        while True:
            try:
                current_time = datetime.now(timezone.utc)
                print(f"\n⏰ {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')} - Checking {exchange.upper()}...")
                
                for symbol, strategy in strategies.items():
                    try:
                        # Fetch recent data
                        fetch_start = current_time - timedelta(minutes=15)
                        candles = fetch_ohlcv_live(
                            client, exchange, symbol, granularity, fetch_start, current_time
                        )
                        
                        if not candles:
                            print(f"   📭 No data received for {symbol}")
                            continue
                        
                        # Process new bars
                        new_bars_processed = 0
                        for candle in candles:
                            bar_time, open_price, high, low, close, volume = candle
                            
                            # Skip if already processed
                            if last_processed[symbol] and bar_time <= last_processed[symbol]:
                                continue
                            
                            # Wait for bar to be complete
                            if granularity in ["ONE_MINUTE", "1m"]:
                                bar_end_time = bar_time + timedelta(minutes=1)
                                buffer_seconds = 30
                            elif granularity in ["FIVE_MINUTE", "5m"]:
                                bar_end_time = bar_time + timedelta(minutes=5)
                                buffer_seconds = 60
                            else:
                                bar_end_time = bar_time + timedelta(minutes=1)
                                buffer_seconds = 30
                            
                            if current_time < bar_end_time + timedelta(seconds=buffer_seconds):
                                continue
                            
                            # Store previous state
                            prev_position = getattr(strategy, 'positions', 0)
                            prev_tsi = getattr(strategy, 'm_tsi', 0)
                            
                            # Process bar
                            print(f"   📊 Processing {symbol} {bar_time.strftime('%H:%M:%S UTC')} - C:{close:.2f}")
                            
                            strategy.process_bar(
                                timestamp=bar_time,
                                open_price=open_price,
                                high=high,
                                low=low,
                                close=close,
                                volume=volume
                            )
                            
                            # Check for trading signals
                            new_position = getattr(strategy, 'positions', 0)
                            new_tsi = getattr(strategy, 'm_tsi', 0)
                            
                            # Execute trades if position changed
                            if prev_position != new_position:
                                position_change = new_position - prev_position
                                
                                if position_change > 0:  # BUY signal
                                    print(f"   🟢 {symbol} BUY SIGNAL: {position_change} units @ {close:.2f}")
                                    logger.info(f"BUY SIGNAL - {symbol}: {position_change} @ {close:.2f}")
                                    
                                    # Execute real trade
                                    trade_result = execute_trade(
                                        client=client,
                                        exchange=exchange,
                                        symbol=symbol,
                                        side="buy",
                                        quantity=abs(position_change),
                                        price=close
                                    )
                                    
                                    if trade_result:
                                        logger.info(f"BUY EXECUTED - {symbol}: {position_change} @ {close:.2f}")
                                    
                                elif position_change < 0:  # SELL signal
                                    print(f"   🔴 {symbol} SELL SIGNAL: {abs(position_change)} units @ {close:.2f}")
                                    logger.info(f"SELL SIGNAL - {symbol}: {abs(position_change)} @ {close:.2f}")
                                    
                                    # Execute real trade
                                    trade_result = execute_trade(
                                        client=client,
                                        exchange=exchange,
                                        symbol=symbol,
                                        side="sell",
                                        quantity=abs(position_change),
                                        price=close
                                    )
                                    
                                    if trade_result:
                                        logger.info(f"SELL EXECUTED - {symbol}: {abs(position_change)} @ {close:.2f}")
                                
                                # Save results
                                save_trading_results(strategy, symbol, exchange, "position_change")
                            
                            # Log TSI crossovers
                            if (prev_tsi is not None and 
                                ((prev_tsi < 0 and new_tsi >= 0) or (prev_tsi >= 0 and new_tsi < 0))):
                                print(f"   📈 {symbol} TSI Zero Cross: {prev_tsi:.4f} -> {new_tsi:.4f}")
                            
                            last_processed[symbol] = bar_time
                            new_bars_processed += 1
                        
                        # Show status
                        if new_bars_processed > 0:
                            pos = getattr(strategy, 'positions', 0)
                            equity = getattr(strategy, 'equity', config.get('initial_cash', 100000))
                            print(f"   ✅ {symbol}: {new_bars_processed} new bars, Pos: {pos}, Equity: ${equity:,.2f}")
                        else:
                            pos = getattr(strategy, 'positions', 0)
                            print(f"   🔄 {symbol}: No new bars, Position: {pos}")
                            
                    except Exception as e:
                        print(f"   ❌ Error processing {symbol}: {e}")
                        logger.error(f"Error processing {symbol}: {e}")
                        continue
                
                # Wait for next check
                print(f"   ⏳ Waiting {check_interval} seconds...")
                time.sleep(check_interval)
                
            except KeyboardInterrupt:
                print("\n🛑 Live trading stopped by user")
                break
            except Exception as e:
                print(f"❌ Live trading error: {e}")
                logger.error(f"Live trading error: {e}")
                time.sleep(check_interval)
        
        # Save final state
        print("\n💾 Saving final strategy states...")
        for symbol, strategy in strategies.items():
            save_trading_results(strategy, symbol, exchange, "shutdown")
        
        print("✅ Live trading session ended")
        
    except Exception as e:
        print(f"💥 Fatal error in live mode: {e}")
        logger.error(f"Fatal error in live mode: {e}")

# ---------- Backtest ----------
def run_backtest_mode(exchange: str):
    """Run backtest for selected exchange"""
    print(f"\n📈 BACKTEST MODE - {exchange.upper()}")
    print("="*50)
    
    try:
        config = load_config("config.json")
        
        # Get symbols for this exchange
        if exchange == "bitmart":
            symbols = parse_symbols(config.get('BITMART_SYMBOLS', config.get('SYMBOLS', ['BTC_USDT'])), exchange)
        else:
            symbols = parse_symbols(config.get('COINBASE_SYMBOLS', config.get('SYMBOLS', ['BTC-USD'])), exchange)
        
        # Get resolution from config
        resolution = config.get('RESOLUTION', '5min')
        start_date = config.get('start_date', '2024-01-01')
        end_date = config.get('end_date', datetime.now().strftime('%Y-%m-%d'))
        
        print(f"Exchange: {exchange.upper()}")
        print(f"Symbols: {', '.join(symbols)}")
        print(f"Resolution from config: {resolution}")
        print(f"Trading Window: {start_date} to {end_date}")
        print(f"Initial Cash: ${config.get('initial_cash', 100000):,.2f}")
        print("="*50)
        
        for symbol in symbols:
            try:
                print(f"\n🔍 Backtesting {symbol}...")
                
                # Load data
                data = load_crypto_data(symbol, resolution, exchange)
                if data.empty:
                    print(f"❌ No data for {symbol}")
                    continue
                
                print(f"📊 Loaded {len(data)} bars for {symbol}")
                
                # Create and initialize strategy
                symbol_config = config.copy()
                symbol_config['symbol'] = symbol
                symbol_config['exchange'] = exchange
                symbol_config['start_date'] = start_date
                symbol_config['end_date'] = end_date
                
                strategy = AdaptiveTrendSurferX2(symbol_config)
                
                # Run backtest
                print(f"🔧 Processing {len(data)} bars...")
                success = run_backtest_with_data(strategy, data)
                
                if success:
                    # Get performance report
                    if hasattr(strategy, 'get_performance_report'):
                        report = strategy.get_performance_report()
                        print_performance_report(report, symbol_config)
                    
                    # Save results
                    save_backtest_results(strategy, symbol_config)
                    print(f"✅ Backtest completed for {symbol}")
                else:
                    print(f"❌ Backtest failed for {symbol}")
                    
            except Exception as e:
                print(f"❌ Error backtesting {symbol}: {e}")
                import traceback
                traceback.print_exc()
        
        print(f"\n✅ {exchange.upper()} backtest completed")
        
    except Exception as e:
        print(f"❌ Error in backtest mode: {e}")
        import traceback
        traceback.print_exc()
    
    input("\nPress Enter to continue...")

# ---------- Data Loading ----------
def load_crypto_data(symbol, resolution, exchange):
    """Load cryptocurrency data for backtesting - FIXED VERSION"""
    try:
        # DEBUG: Print what we're looking for
        print(f"🔍 Loading {exchange.upper()} {symbol} at {resolution}")
        
        # FIRST: Try exact resolution as folder name (for BitMart and new Coinbase)
        data_type_exact = resolution.lower().replace(' ', '')
        path_symbol = symbol.replace('-', '').replace('_', '').lower()
        
        # Try exact resolution folder first
        data_path_exact = Path("data/crypto") / exchange / data_type_exact / path_symbol
        print(f"   Trying exact folder: {data_path_exact}")
        
        if data_path_exact.exists():
            data_path = data_path_exact
            print(f"   ✅ Found data in exact resolution folder: {data_type_exact}")
        else:
            # SECOND: Try mapped folders (for old Coinbase structure)
            if 'min' in resolution.lower():
                data_type_mapped = 'minute'
            elif 'hour' in resolution.lower():
                data_type_mapped = 'hour'
            elif 'day' in resolution.lower():
                data_type_mapped = 'daily'
            else:
                data_type_mapped = 'minute'
            
            data_path_mapped = Path("data/crypto") / exchange / data_type_mapped / path_symbol
            print(f"   Trying mapped folder: {data_path_mapped}")
            
            if data_path_mapped.exists():
                data_path = data_path_mapped
                print(f"   ✅ Found data in mapped folder: {data_type_mapped}")
            else:
                print(f"❌ No data directory found at either:")
                print(f"   {data_path_exact}")
                print(f"   {data_path_mapped}")
                return pd.DataFrame()
        
        # Get all CSV files
        csv_files = list(data_path.glob("*.csv"))
        if not csv_files:
            print(f"❌ No CSV files in {data_path}")
            return pd.DataFrame()
        
        print(f"📥 Loading {len(csv_files)} files from {data_path}")
        
        all_data = []
        for csv_file in sorted(csv_files):
            try:
                df = pd.read_csv(csv_file, header=None)
                df.columns = ['time', 'open', 'high', 'low', 'close', 'volume']
                
                # Extract date from filename (handle both YYYYMMDD.csv and YYYYMMDD_trade.csv)
                filename = csv_file.stem
                # Remove '_trade' suffix if present
                if '_trade' in filename:
                    file_date_str = filename.replace('_trade', '')
                elif '_' in filename:
                    file_date_str = filename.split('_')[0]
                else:
                    file_date_str = filename
                
                file_datetime = datetime.strptime(file_date_str, "%Y%m%d").replace(tzinfo=timezone.utc)
                
                # Convert milliseconds to timedelta
                df['timestamp'] = df['time'].apply(lambda ms: file_datetime + timedelta(milliseconds=ms))
                
                all_data.append(df)
                print(f"   ✅ Loaded {csv_file.name} ({len(df)} bars)")
                
            except Exception as e:
                print(f"⚠️ Error reading {csv_file.name}: {e}")
                continue
        
        if not all_data:
            print(f"⚠️ No data could be loaded from CSV files")
            return pd.DataFrame()
        
        # Combine all data
        combined_df = pd.concat(all_data, ignore_index=True)
        combined_df = combined_df.sort_values('timestamp').reset_index(drop=True)
        
        # Clean data
        for col in ['open', 'high', 'low', 'close', 'volume']:
            combined_df[col] = pd.to_numeric(combined_df[col], errors='coerce')
        
        combined_df = combined_df.dropna(subset=['timestamp', 'open', 'high', 'low', 'close'])
        combined_df['symbol'] = symbol.upper()
        
        print(f"✅ Loaded {len(combined_df)} bars for {symbol}")
        
        if not combined_df.empty:
            actual_start = combined_df['timestamp'].min()
            actual_end = combined_df['timestamp'].max()
            print(f"   Date range: {actual_start.strftime('%Y-%m-%d')} to {actual_end.strftime('%Y-%m-%d')}")
            print(f"   Days: {(actual_end - actual_start).days + 1}")
        
        return combined_df
        
    except Exception as e:
        print(f"❌ Error loading data for {symbol}: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()
    
def run_backtest_with_data(strategy, data):
    """Run backtest with provided data"""
    try:
        processed_bars = 0
        total_bars = len(data)
        
        start_date = getattr(strategy, 'trading_start_date', None)
        end_date = getattr(strategy, 'trading_end_date', None)
        
        print(f"🔧 Processing {total_bars} bars...")
        
        for _, row in data.iterrows():
            timestamp = row['timestamp']
            open_price = float(row['open'])
            high = float(row['high'])
            low = float(row['low'])
            close = float(row['close'])
            volume = float(row.get('volume', 0))
            
            # Process bar
            strategy.process_bar(
                timestamp=timestamp,
                open_price=open_price,
                high=high,
                low=low,
                close=close,
                volume=volume
            )
            
            processed_bars += 1
            
            if processed_bars % 1000 == 0:
                progress = (processed_bars / total_bars) * 100
                print(f"   📊 Progress: {processed_bars}/{total_bars} ({progress:.1f}%)")
        
        print(f"✅ Processed {processed_bars} bars")
        
        # Log trades
        trades = getattr(strategy, 'trades', [])
        if trades:
            print(f"📊 Total trades: {len(trades)}")
        
        return True
        
    except Exception as e:
        print(f"❌ Backtest failed: {e}")
        return False

def save_backtest_results(strategy, config):
    """Save backtest results"""
    try:
        os.makedirs('results/backtest', exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        symbol = config.get('symbol', 'Unknown')
        exchange = config.get('exchange', 'coinbase')
        
        # Save trades
        if hasattr(strategy, 'trades') and strategy.trades:
            trades_df = pd.DataFrame(strategy.trades)
            trades_file = f"results/backtest/{exchange}_{symbol}_{timestamp}_trades.csv"
            trades_df.to_csv(trades_file, index=False)
            print(f"💾 Trades saved: {trades_file}")
        
        # Save performance report
        if hasattr(strategy, 'get_performance_report'):
            report = strategy.get_performance_report()
            
            summary = {
                'backtest_timestamp': timestamp,
                'symbol': symbol,
                'exchange': exchange,
                'performance_report': report
            }
            
            summary_file = f"results/backtest/{exchange}_{symbol}_{timestamp}_summary.json"
            with open(summary_file, 'w') as f:
                json.dump(summary, f, indent=2, default=str)
            print(f"💾 Summary saved: {summary_file}")
            
            return report
        
        return None
        
    except Exception as e:
        print(f"❌ Error saving results: {e}")
        return None

def print_performance_report(report, config):
    """Print performance report"""
    print("\n" + "="*60)
    print("📈 PERFORMANCE REPORT")
    print("="*60)
    
    if report:
        print(f"Symbol: {config.get('symbol', 'Unknown')}")
        print(f"Exchange: {config.get('exchange', 'coinbase').upper()}")
        print(f"Initial Capital: ${config.get('initial_cash', 0):,.2f}")
        print(f"Trading Window: {config.get('start_date', 'All data')} to {config.get('end_date', 'Present')}")
        print()
        print(f"Total Trades: {report.get('total_trades', 0)}")
        print(f"Winning Trades: {report.get('winning_trades', 0)}")
        print(f"Losing Trades: {report.get('losing_trades', 0)}")
        print(f"Win Rate: {report.get('win_rate', 0):.2f}%")
        print(f"Total PnL: ${report.get('total_pnl', 0):,.2f}")
        print(f"Final Equity: ${report.get('final_equity', 0):,.2f}")
        print(f"Max Drawdown: ${report.get('max_drawdown', 0):,.2f} ({report.get('max_drawdown_pct', 0):.2f}%)")
        print(f"Profit Factor: {report.get('profit_factor', 0):.2f}")
    else:
        print("No trades executed during backtest period")
    
    print("="*60)

# ---------- Data Management ----------
def download_data_mode(exchange: str):
    """Download data for selected exchange - UNIFIED VERSION"""
    print(f"\n📥 DOWNLOAD DATA - {exchange.upper()}")
    print("="*50)
    
    try:
        config = load_config("config.json")
        
        if exchange == "coinbase":
            try:
                from fetch_coinbase import main as fetch_main
                print("Starting Coinbase data download...")
                fetch_main()
                print("✅ Coinbase data download completed!")
            except Exception as e:
                print(f"❌ Coinbase download error: {e}")
        
        elif exchange == "bitmart":
            try:
                from bitmart_api import BitMartRESTClient
                
                # Get symbols for BitMart
                symbols = parse_symbols(config.get('BITMART_SYMBOLS', config.get('SYMBOLS')), exchange)
                resolution = config.get('RESOLUTION')
                
                print(f"Downloading {len(symbols)} symbols at {resolution} resolution...")
                
                # Create client
                client = BitMartRESTClient()
                
                # Get date range from config
                try:
                    start_date_str = config.get('download_start_date', '2025-11-30')
                    end_date_str = config.get('download_end_date', datetime.now().strftime('%Y-%m-%d'))
                    
                    # Parse dates
                    start_time = datetime.strptime(start_date_str, "%Y-%m-%d").replace(
                        hour=0, minute=0, second=0, tzinfo=timezone.utc
                    )
                    end_time = datetime.strptime(end_date_str, "%Y-%m-%d").replace(
                        hour=23, minute=59, second=59, tzinfo=timezone.utc
                    )
                    
                    # Adjust end_time if it's in the future
                    current_time = datetime.now(timezone.utc)
                    if end_time > current_time:
                        print(f"⚠️  End date is in the future, adjusting to current time")
                        end_time = current_time
                    
                    print(f"📅 Date range: {start_time.strftime('%Y-%m-%d %H:%M:%S')} to {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
                    print(f"⏱️  Duration: {(end_time - start_time).days} days")
                    
                except Exception as e:
                    print(f"⚠️  Error parsing dates from config: {e}")
                    print("Using default 3-day range...")
                    end_time = datetime.now(timezone.utc)
                    start_time = end_time - timedelta(days=3)
                
                for symbol in symbols:
                    print(f"\n{'='*60}")
                    print(f"📊 Downloading {symbol}...")
                    print(f"   Resolution: {resolution}")
                    print(f"   Date Range: {start_time.strftime('%Y-%m-%d')} to {end_time.strftime('%Y-%m-%d')}")
                    
                    try:
                        # Calculate timeframe in seconds
                        timeframe_seconds = {
                                '1min': 60, '3min': 180, '4min': 240, '5min': 300, '15min': 900, 
                                '30min': 1800, '36min': 2160, '78min': 4680,
                                '1hour': 3600, '2hour': 7200, '4hour': 14400, '6hour': 21600, '12hour': 43200,
                                '1day': 86400, '3day': 259200, '1week': 604800, '1month': 2592000
                            }.get(resolution.lower(), 300)
                        
                        # BitMart API limit: 200 candles per request
                        BATCH_SIZE = 200
                        
                        # Start from end_time and work backwards
                        current_before = int(end_time.timestamp())
                        start_seconds = int(start_time.timestamp())
                        
                        all_candles = []
                        batch_num = 0
                        MAX_BATCHES = 100  # Safety limit
                        
                        # Calculate expected candles
                        total_seconds = current_before - start_seconds
                        expected_candles = total_seconds // timeframe_seconds + 1
                        expected_batches = (expected_candles + BATCH_SIZE - 1) // BATCH_SIZE
                        
                        print(f"   Expected: ~{expected_candles} candles, {expected_batches} batches")
                        
                        # Batch fetching loop
                        while current_before > start_seconds and batch_num < MAX_BATCHES:
                            batch_num += 1
                            
                            # Calculate time range for this batch
                            batch_start_time = current_before - (BATCH_SIZE * timeframe_seconds)
                            if batch_start_time < start_seconds:
                                batch_start_time = start_seconds
                            
                            print(f"   Batch {batch_num}: ", end="")
                            print(f"{datetime.fromtimestamp(batch_start_time, tz=timezone.utc).strftime('%Y-%m-%d %H:%M')} to "
                                f"{datetime.fromtimestamp(current_before, tz=timezone.utc).strftime('%Y-%m-%d %H:%M')}")
                            
                            # Fetch batch using get_klines (which works, as shown in your logs)
                            batch_candles = client.get_klines(
                                symbol=symbol,
                                timeframe=resolution,
                                limit=BATCH_SIZE,
                                before=current_before
                            )
                            
                            if not batch_candles:
                                print(f"      No data returned")
                                break
                            
                            print(f"      Retrieved {len(batch_candles)} candles")
                            
                            # Process candles
                            if batch_candles:
                                # Filter candles within our range
                                valid_candles = [
                                    c for c in batch_candles
                                    if start_seconds <= int(c['timestamp'].timestamp()) <= current_before
                                ]
                                
                                if valid_candles:
                                    all_candles.extend(valid_candles)
                                    
                                    # Find oldest candle in this batch
                                    oldest_ts = min(int(c['timestamp'].timestamp()) for c in valid_candles)
                                    
                                    # Move window back (minus 1 to avoid overlap)
                                    current_before = oldest_ts - 1
                                    
                                    # Progress tracking
                                    progress = 100 * (1 - (current_before - start_seconds) / total_seconds)
                                    print(f"      Progress: {progress:.1f}% - Oldest: {datetime.fromtimestamp(oldest_ts, tz=timezone.utc).strftime('%H:%M')}")
                                    
                                    # Check if we've reached start time
                                    if oldest_ts <= start_seconds:
                                        print(f"      ✓ Reached start time")
                                        break
                                else:
                                    print(f"      No valid candles in range")
                                    break
                            else:
                                break
                            
                            # Rate limiting
                            time.sleep(0.2)
                        
                        # Process all collected candles
                        if not all_candles:
                            print(f"⚠️  No candles collected for {symbol}")
                            continue
                        
                        # Remove duplicates by timestamp
                        seen_timestamps = set()
                        unique_candles = []
                        
                        for candle in all_candles:
                            ts = int(candle['timestamp'].timestamp())
                            if ts not in seen_timestamps:
                                seen_timestamps.add(ts)
                                unique_candles.append(candle)
                        
                        # Sort by timestamp
                        unique_candles.sort(key=lambda x: x['timestamp'])
                        
                        print(f"✅ Collected {len(unique_candles)} unique candles")
                        
                        if unique_candles:
                            first = unique_candles[0]['timestamp']
                            last = unique_candles[-1]['timestamp']
                            
                            print(f"📅 Actual range: {first.strftime('%Y-%m-%d %H:%M')} to {last.strftime('%Y-%m-%d %H:%M')}")
                            
                            # Calculate statistics
                            actual_duration = (last - first).total_seconds() / 86400  # days
                            requested_duration = (end_time - start_time).total_seconds() / 86400
                            
                            if requested_duration > 0:
                                coverage = (actual_duration / requested_duration) * 100
                                print(f"📊 Coverage: {coverage:.1f}% of requested time")
                            
                            # Group by date for analysis
                            candles_by_date = {}
                            for candle in unique_candles:
                                date_key = candle['timestamp'].date()
                                candles_by_date[date_key] = candles_by_date.get(date_key, 0) + 1
                            
                            if candles_by_date:
                                sorted_dates = sorted(candles_by_date.items())
                                print(f"📆 Days with data: {len(sorted_dates)}")
                                
                                # Show completeness for each day
                                candles_per_day = 86400 / timeframe_seconds  # Expected candles per day
                                print(f"   Expected per day: ~{candles_per_day:.0f} candles")
                                
                                for date, count in sorted_dates[:5]:  # Show first 5 days
                                    completeness = (count / candles_per_day * 100) if candles_per_day > 0 else 0
                                    print(f"   {date}: {count} candles ({completeness:.1f}% complete)")
                                
                                if len(sorted_dates) > 5:
                                    print(f"   ... and {len(sorted_dates)-5} more days")
                        
                        # Save to CSV
                        success = save_bitmart_data_to_csv(
                            candles=unique_candles,
                            symbol=symbol,
                            timeframe=resolution,
                            start_time=start_time,
                            end_time=end_time
                        )
                        
                        if success:
                            print(f"💾 Data saved successfully")
                            
                            # Verify saved files - FIXED: use correct directory and file pattern
                            clean_symbol = symbol.replace('_', '').replace('-', '').lower()
                            data_type = resolution.lower().replace(' ', '')
                            data_dir = Path("data/crypto/bitmart") / data_type / clean_symbol
                            
                            if data_dir.exists():
                                csv_files = list(data_dir.glob("*.csv"))  # FIXED: not *_trade.csv
                                if csv_files:
                                    total_lines = 0
                                    print(f"📁 Files created:")
                                    for csv_file in sorted(csv_files)[:10]:  # Show first 10 files
                                        with open(csv_file, 'r', encoding='utf-8') as f:
                                            line_count = sum(1 for _ in f)
                                        total_lines += line_count
                                        date_str = csv_file.stem
                                        print(f"   {date_str}.csv: {line_count} candles")
                                    
                                    if len(csv_files) > 10:
                                        print(f"   ... and {len(csv_files)-10} more files")
                                    
                                    print(f"📊 Total: {len(csv_files)} files, {total_lines} candles")
                        else:
                            print(f"⚠️  CSV save had issues")
                        
                    except Exception as e:
                        print(f"❌ Error downloading {symbol}: {e}")
                        import traceback
                        traceback.print_exc()
                    
                    # Rate limiting between symbols
                    if symbol != symbols[-1]:
                        print(f"⏳ Waiting 2 seconds before next symbol...")
                        time.sleep(2)
                
                print(f"\n✅ {exchange.upper()} download completed")
                print(f"   - Resolution: {resolution}")
                print(f"   - Symbols processed: {len(symbols)}")
                print(f"   - Requested date range: {start_time.strftime('%Y-%m-%d')} to {end_time.strftime('%Y-%m-%d')}")
                
            except Exception as e:
                print(f"❌ BitMart download error: {e}")
                import traceback
                traceback.print_exc()
    except Exception as e:
        print(f"❌ Error in download mode: {e}")
        import traceback
        traceback.print_exc()
    
    input("\nPress Enter to continue...")
    
def save_bitmart_data_to_csv(candles, symbol, timeframe, start_time=None, end_time=None):
    """Save BitMart data to CSV with DAILY FILES (like Coinbase format)"""
    if not candles or len(candles) == 0:
        print(f"⚠️  No candles to save for {symbol}")
        return False
    
    try:
        # Clean symbol for file path
        clean_symbol = symbol.replace('_', '').replace('-', '').lower()
        
        data_type = str(timeframe).lower().replace(' ', '')
        
        # Create directory structure
        base_dir = Path("data/crypto")
        exchange_dir = base_dir / "bitmart"
        type_dir = exchange_dir / data_type
        symbol_dir = type_dir / clean_symbol
        
        symbol_dir.mkdir(parents=True, exist_ok=True)
        
        # Group candles by DATE (not including time)
        candles_by_date = {}
        for candle in candles:
            date_key = candle['timestamp'].date()  # Just the date part
            if date_key not in candles_by_date:
                candles_by_date[date_key] = []
            candles_by_date[date_key].append(candle)
        
        total_saved = 0
        
        # Save each day's data to a separate file
        for date_key, daily_candles in candles_by_date.items():
            # Sort candles by timestamp for this day
            daily_candles.sort(key=lambda x: x['timestamp'])
            
            # Format date for filename (YYYYMMDD)
            date_str = date_key.strftime("%Y%m%d")
            filename = f"{date_str}.csv"
            csv_path = symbol_dir / filename
            
            print(f"   💾 Saving {date_str}: {len(daily_candles)} candles")
            
            # Check if file already exists
            file_exists = csv_path.exists()
            
            if file_exists:
                # Read existing data
                existing_candles = []
                try:
                    with open(csv_path, 'r', encoding='utf-8') as f:
                        reader = csv.reader(f)
                        for row in reader:
                            if len(row) >= 6:
                                # Parse timestamp from milliseconds
                                timestamp_ms = int(row[0])
                                timestamp_dt = datetime.fromtimestamp(timestamp_ms / 1000, tz=timezone.utc)
                                
                                # Only keep if same date
                                if timestamp_dt.date() == date_key:
                                    existing_candles.append({
                                        'timestamp': timestamp_dt,
                                        'open': float(row[1]),
                                        'high': float(row[2]),
                                        'low': float(row[3]),
                                        'close': float(row[4]),
                                        'volume': float(row[5])
                                    })
                except Exception as e:
                    print(f"      ⚠️ Error reading existing file: {e}")
                    existing_candles = []
                
                # Merge new candles with existing
                all_candles_dict = {}
                
                # Add existing candles
                for candle in existing_candles:
                    ts_key = int(candle['timestamp'].timestamp() * 1000)  # Use ms as key
                    all_candles_dict[ts_key] = candle
                
                # Add/update with new candles
                for candle in daily_candles:
                    ts_key = int(candle['timestamp'].timestamp() * 1000)
                    all_candles_dict[ts_key] = candle
                
                # Convert back to list and sort
                merged_candles = list(all_candles_dict.values())
                merged_candles.sort(key=lambda x: x['timestamp'])
                
                final_candles = merged_candles
                print(f"      🔄 Merged: {len(existing_candles)} existing + {len(daily_candles)} new = {len(final_candles)} total")
            else:
                final_candles = daily_candles
                print(f"      📝 Creating new file")
            
            # Write to CSV
            with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                
                # Write data
                for candle in final_candles:
                    timestamp = candle['timestamp']
                    
                    # Calculate milliseconds since midnight (LEAN format)
                    ms_since_midnight = (
                        (timestamp.hour * 3600 + timestamp.minute * 60 + timestamp.second) * 1000
                        + timestamp.microsecond // 1000
                    )
                    
                    writer.writerow([
                        ms_since_midnight,
                        f"{candle['open']:.8f}",
                        f"{candle['high']:.8f}",
                        f"{candle['low']:.8f}",
                        f"{candle['close']:.8f}",
                        f"{candle['volume']:.8f}"
                    ])
            
            total_saved += len(daily_candles)
        
        print(f"   ✅ Saved {total_saved} candles across {len(candles_by_date)} day(s)")
        
        # Also create/update a metadata file
        metadata_path = symbol_dir / "metadata.json"
        metadata = {}
        
        if metadata_path.exists():
            try:
                with open(metadata_path, 'r', encoding='utf-8') as f:
                    metadata = json.load(f)
            except:
                metadata = {}
        
        # Update metadata
        if 'download_history' not in metadata:
            metadata['download_history'] = []
        
        metadata['download_history'].append({
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'timeframe': timeframe,
            'candles_added': len(candles),
            'date_range': {
                'start': candles[0]['timestamp'].isoformat(),
                'end': candles[-1]['timestamp'].isoformat()
            }
        })
        
        # Keep only last 10 download records
        if len(metadata['download_history']) > 10:
            metadata['download_history'] = metadata['download_history'][-10:]
        
        metadata['last_updated'] = datetime.now(timezone.utc).isoformat()
        metadata['total_days'] = len(candles_by_date)
        
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2, default=str)
        
        print(f"   📝 Metadata updated: {metadata_path}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error saving BitMart data for {symbol}: {e}")
        import traceback
        traceback.print_exc()
        return False
    
def show_data_mode(exchange: str):
    """Show available data files for exchange - ENHANCED for daily files"""
    print(f"\n📊 SHOW DATA - {exchange.upper()}")
    print("="*50)
    
    try:
        base_dir = Path("data/crypto") / exchange
        
        if not base_dir.exists():
            print(f"❌ No data directory for {exchange}")
            print(f"   Path: {base_dir.absolute()}")
            print("   Please download data first.")
            input("Press Enter to continue...")
            return
        
        data_found = False
        
        print(f"Exploring: {base_dir.absolute()}\n")
        
        # List all data types
        for data_type in sorted(base_dir.iterdir()):
            if data_type.is_dir():
                print(f"\n📈 {data_type.name.upper()}:")
                print("-" * 40)
                
                # List all symbols
                symbol_dirs = sorted([d for d in data_type.iterdir() if d.is_dir()])
                
                if not symbol_dirs:
                    print("  (No symbol directories found)")
                    continue
                
                for symbol_dir in symbol_dirs:
                    csv_files = list(symbol_dir.glob("*.csv"))
                    json_files = list(symbol_dir.glob("*.json"))
                    
                    if csv_files:
                        # Format symbol name for display
                        dir_name = symbol_dir.name.upper()
                        if len(dir_name) == 6:
                            if exchange == "coinbase":
                                display_name = f"{dir_name[:3]}-{dir_name[3:]}"
                            else:  # bitmart
                                display_name = f"{dir_name[:3]}_{dir_name[3:]}"
                        else:
                            display_name = dir_name
                        
                        print(f"\n  💰 {display_name}:")
                        print(f"     Path: {symbol_dir.relative_to(base_dir)}")
                        print(f"     Daily files: {len(csv_files)}")
                        
                        # Show date range
                        dates = []
                        for csv_file in csv_files:
                            try:
                                # Extract date from filename (YYYYMMDD.csv)
                                date_str = csv_file.stem
                                if date_str.isdigit() and len(date_str) == 8:
                                    date_obj = datetime.strptime(date_str, "%Y%m%d")
                                    dates.append(date_obj)
                            except:
                                pass
                        
                        if dates:
                            dates.sort()
                            oldest = dates[0].strftime("%Y-%m-%d")
                            newest = dates[-1].strftime("%Y-%m-%d")
                            total_days = len(dates)
                            
                            print(f"     📅 Date range: {oldest} to {newest}")
                            print(f"     📆 Total days: {total_days}")
                            
                            # Check for gaps
                            if len(dates) > 1:
                                date_set = set(dates)
                                full_range = set([
                                    dates[0] + timedelta(days=i) 
                                    for i in range((dates[-1] - dates[0]).days + 1)
                                ])
                                missing_days = sorted(full_range - date_set)
                                
                                if missing_days:
                                    print(f"     ⚠️  Missing {len(missing_days)} days")
                                    if len(missing_days) <= 5:
                                        missing_dates = [d.strftime("%Y-%m-%d") for d in missing_days]
                                        print(f"        Missing: {', '.join(missing_dates)}")
                        
                        # Show metadata if exists
                        metadata_file = symbol_dir / "metadata.json"
                        if metadata_file.exists():
                            try:
                                with open(metadata_file, 'r', encoding='utf-8') as f:
                                    metadata = json.load(f)
                                
                                if 'last_updated' in metadata:
                                    last_updated = datetime.fromisoformat(metadata['last_updated'])
                                    print(f"     🔄 Last updated: {last_updated.strftime('%Y-%m-%d %H:%M:%S')}")
                                
                                if 'download_history' in metadata:
                                    total_downloads = len(metadata['download_history'])
                                    print(f"     📥 Total downloads: {total_downloads}")
                            except:
                                pass
                        
                        # Show sample data from latest file
                        if csv_files:
                            latest_file = max(csv_files, key=lambda x: x.stat().st_mtime)
                            try:
                                file_size = latest_file.stat().st_size / 1024
                                
                                # Count lines in latest file
                                with open(latest_file, 'r', encoding='utf-8') as f:
                                    line_count = sum(1 for _ in f)
                                
                                print(f"     📁 Latest: {latest_file.name} ({file_size:.1f} KB, {line_count} candles)")
                                
                                # Show first few candles
                                if line_count > 0 and line_count <= 1000:  # Only for reasonable sizes
                                    with open(latest_file, 'r', encoding='utf-8') as f:
                                        reader = csv.reader(f)
                                        first_row = next(reader, None)
                                        if first_row and len(first_row) >= 6:
                                            print(f"     📊 Sample: Time={first_row[0]}ms, Close={first_row[4]}")
                            except Exception as e:
                                print(f"     ⚠️  Could not read {latest_file.name}: {e}")
                        
                        data_found = True
        
        if not data_found:
            print(f"❌ No data files found for {exchange}")
            print("   Directory structure might be incorrect.")
            print("   Expected: data/crypto/{exchange}/{data_type}/{symbol}/YYYYMMDD.csv")
        else:
            print(f"\n✅ {exchange.upper()} data exploration completed")
            
            # Show summary
            total_csv = sum(1 for _ in Path(base_dir).rglob("*.csv"))
            total_dirs = sum(1 for _ in Path(base_dir).rglob("*") if _.is_dir())
            print(f"\n📊 Summary for {exchange.upper()}:")
            print(f"   Total CSV files: {total_csv}")
            print(f"   Total directories: {total_dirs}")
            
    except Exception as e:
        print(f"❌ Error showing data: {e}")
        import traceback
        traceback.print_exc()
    
    input("\nPress Enter to continue...")

# ---------- Main Menu ----------
def main():
    """Main trading system"""
    print("\n" + "="*60)
    print("ADAPTIVE TREND SURFER X2 TRADING SYSTEM")
    print("="*60)
    print("Version 4.0 - Unified Multi-Exchange Support")
    print("Features: Live Trading, Backtesting, Real Order Execution")
    print("Uses config.json for all settings")
    print("\n")
    
    while True:
        # Select exchange
        exchange = select_exchange()
        if exchange == "exit":
            print("\n👋 Thank you for using AdaptiveTrendSurferX2 Trading System!")
            break
        
        while True:
            # Select mode for this exchange
            mode_choice = select_mode()
            
            if mode_choice == "5":  # Return to exchange selection
                break
            
            # Execute based on mode
            if mode_choice == "1":  # Live Trading
                run_live_mode(exchange)
                
            elif mode_choice == "2":  # Backtest
                run_backtest_mode(exchange)
                
            elif mode_choice == "3":  # Download Data
                download_data_mode(exchange)
                
            elif mode_choice == "4":  # Show Data
                show_data_mode(exchange)
            
            # Ask to continue with same exchange
            print("\n" + "="*50)
            continue_same = input(f"Continue with {exchange.upper()}? (y/n): ").lower()
            if continue_same != 'y':
                break

# ---------- Quick Start ----------
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n🛑 Program interrupted by user")
    except Exception as e:
        print(f"\n💥 Fatal error: {e}")
        import traceback
        traceback.print_exc()
    
    input("\nPress Enter to close...")