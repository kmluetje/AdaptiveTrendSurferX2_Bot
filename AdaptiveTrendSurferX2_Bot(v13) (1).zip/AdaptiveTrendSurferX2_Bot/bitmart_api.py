"""
BitMart API Implementation using REST API (No SDK required)
FIXED VERSION - Uses config RESOLUTION and follows same pattern as Coinbase
"""

import os
import sys
import json
import time
import hmac
import hashlib
import base64
import requests
import logging
import csv
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlencode
import pandas as pd

# ---------- Setup Logging ----------
def setup_bitmart_logging():
    """Setup logging for BitMart operations"""
    log_dir = Path("logs/bitmart")
    log_dir.mkdir(parents=True, exist_ok=True)
    
    log_file = log_dir / f"bitmart_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    
    logger = logging.getLogger("bitmart_api")
    logger.setLevel(logging.INFO)
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # File handler
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(console_handler)
    
    return logger, log_file

# ---------- Configuration ----------
def find_config_file(filename: str) -> Path:
    """Find configuration file in multiple locations"""
    if getattr(sys, 'frozen', False):
        base_dir = getattr(sys, '_MEIPASS', Path(sys.executable).parent)
    else:
        base_dir = Path(__file__).parent
    
    possible_paths = [
        base_dir / filename,
        base_dir / "secrets" / filename,
        base_dir.parent / filename,
        base_dir.parent / "secrets" / filename,
        Path(filename)
    ]
    
    for path in possible_paths:
        if path.exists():
            return path
    raise FileNotFoundError(f"Config file not found: {filename}")

# SIMPLIFY THIS:
def load_bitmart_credentials() -> Dict:
    """Simple credential loading"""
    try:
        # Just check common locations
        possible_paths = [
            Path("bitmart_api_key.json"),
            Path("secrets/bitmart_api_key.json"),
            Path(__file__).parent / "bitmart_api_key.json"
        ]
        
        for path in possible_paths:
            if path.exists():
                with open(path, 'r') as f:
                    return json.load(f)
        
        # Fallback to env vars
        return {
            'api_key': os.getenv('BITMART_API_KEY', ''),
            'secret_key': os.getenv('BITMART_SECRET_KEY', ''),
            'memo': os.getenv('BITMART_MEMO', '')
        }
    except Exception:
        return {'api_key': '', 'secret_key': '', 'memo': ''}
    


# ---------- BitMart REST API Client ----------
class BitMartRESTClient:
    """BitMart REST API client (No SDK required)"""
    
    BASE_URL = "https://api-cloud.bitmart.com"
    
    def __init__(self, credentials: Dict = None, logger=None):
        self.logger = logger or setup_bitmart_logging()[0]
        
        if credentials is None:
            credentials = load_bitmart_credentials()
        
        self.api_key = credentials.get('api_key', '')
        self.secret_key = credentials.get('secret_key', '')
        self.memo = credentials.get('memo', '')
        
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
        })
        
        self.last_request_time = 0
        self.min_request_interval = 0.2
        
        # Debug: Show credentials loaded
        print(f"✅ API Key: {self.api_key[:8]}...")
        print(f"✅ Memo: {self.memo}")
    
    def _rate_limit(self):
        """Implement rate limiting"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        if time_since_last < self.min_request_interval:
            time.sleep(self.min_request_interval - time_since_last)
        self.last_request_time = time.time()
    
    def _generate_signature(self, timestamp: str, query_string: str = '') -> str:
        """Generate signature for authenticated requests"""
        # DEBUG: Print what's being signed
        message = timestamp + '#' + self.memo + '#' + query_string
        self.logger.debug(f"Signing message: {message}")
        
        signature = hmac.new(
            self.secret_key.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        
        self.logger.debug(f"Generated signature: {signature[:20]}...")
        return signature
    
    def _public_request(self, endpoint: str, params: Dict = None) -> Optional[Dict]:
        """Make public API request - DEBUG VERSION"""
        try:
            self._rate_limit()
            url = f"{self.BASE_URL}{endpoint}"
            
            # self.logger.info(f"🌐 Request: {url}")
            self.logger.info(f"🔍 Params: {params}")
            
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            
            # Log raw response
            self.logger.info(f"📥 Response status: {response.status_code}")
            # self.logger.info(f"📥 Response headers: {dict(response.headers)}")
            
            # Check if response is JSON
            content_type = response.headers.get('content-type', '')
            if 'application/json' not in content_type:
                self.logger.error(f"Non-JSON response received: {content_type}")
                self.logger.error(f"Response text: {response.text[:200]}")
                return None
            
            data = response.json()
            # self.logger.info(f"📊 Response data type: {type(data)}")
            # self.logger.info(f"📊 Response keys: {list(data.keys()) if isinstance(data, dict) else 'Not a dict'}")
            
            # Check for API errors
            if isinstance(data, dict):
                if data.get('code') != 1000:
                    error_msg = data.get('message', f"Unknown error (code: {data.get('code')})")
                    self.logger.error(f"BitMart API Error: {error_msg}")
                    self.logger.error(f"Full error response: {data}")
                    return None
                
                result_data = data.get('data')
                # self.logger.info(f"✅ API code: {data.get('code')}, message: {data.get('message', 'No message')}")
                
                # if isinstance(result_data, list):
                #     self.logger.info(f"📈 Data is list with {len(result_data)} items")
                #     if result_data:
                #         self.logger.info(f"📈 First item: {result_data[0]}")
                # elif isinstance(result_data, dict):
                #     self.logger.info(f"📈 Data is dict with keys: {list(result_data.keys())}")
                # else:
                #     self.logger.info(f"📈 Data type: {type(result_data)}")
                
                return result_data
            else:
                self.logger.warning(f"Response is not a dict: {type(data)}")
                return data
                    
        except Exception as e:
            self.logger.error(f"Request error: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _private_request(self, method: str, endpoint: str, params: Dict = None) -> Optional[Dict]:
        """Make authenticated API request - DEBUGGED VERSION"""
        try:
            self._rate_limit()
            url = f"{self.BASE_URL}{endpoint}"
            
            timestamp = str(int(time.time() * 1000))
            self.logger.info(f"Timestamp: {timestamp}")
            
            if method.upper() == 'GET':
                # For GET: signature uses sorted query parameters
                query_string = ''
                if params:
                    # Sort params alphabetically
                    sorted_params = sorted(params.items())
                    query_string = urlencode(sorted_params)
                    url = f"{url}?{query_string}"
                
                self.logger.info(f"GET Query String: '{query_string}'")
                signature = self._generate_signature(timestamp, query_string)
                
                headers = {
                    'X-BM-KEY': self.api_key,
                    'X-BM-TIMESTAMP': timestamp,
                    'X-BM-SIGN': signature,
                    'Content-Type': 'application/json'
                }
                
                self.logger.info(f"GET Headers: X-BM-TIMESTAMP={timestamp}, X-BM-SIGN={signature[:20]}...")
                response = self.session.get(url, headers=headers, timeout=10)
                
            else:  # POST request
                # For POST: signature uses the JSON body
                body = json.dumps(params, separators=(',', ':')) if params else ''
                self.logger.info(f"POST Body: {body}")
                
                signature = self._generate_signature(timestamp, body)
                
                headers = {
                    'X-BM-KEY': self.api_key,
                    'X-BM-TIMESTAMP': timestamp,
                    'X-BM-SIGN': signature,
                    'Content-Type': 'application/json'
                }
                
                self.logger.info(f"POST Headers: X-BM-TIMESTAMP={timestamp}, X-BM-SIGN={signature[:20]}...")
                response = self.session.post(url, headers=headers, data=body, timeout=10)
            
            # Log full response for debugging
            self.logger.info(f"Response Status: {response.status_code}")
            self.logger.info(f"Response Body: {response.text}")
            
            response.raise_for_status()
            data = response.json()
            
            if data.get('code') == 1000:
                return data.get('data')
            else:
                error_msg = data.get('message', f"Error code: {data.get('code')}")
                self.logger.error(f"BitMart API Error: {error_msg}")
                return None
                
        except requests.exceptions.HTTPError as e:
            self.logger.error(f"HTTP Error {e.response.status_code}: {e.response.text}")
            return None
        except Exception as e:
            self.logger.error(f"Request error: {e}")
            return None
        
    # ---------- Market Data Methods ----------
    def get_ticker(self, symbol: str) -> Optional[Dict]:
        """Get current ticker information"""
        endpoint = "/spot/v1/ticker"
        formatted_symbol = symbol.replace('-', '_').upper()
        params = {'symbol': formatted_symbol}
        
        data = self._public_request(endpoint, params)
        if data and 'tickers' in data and data['tickers']:
            return data['tickers'][0]
        return None
    
    def get_klines(self, symbol: str, timeframe: str, limit: int, before: int = None, after: int = None) -> List[Dict]:
        """
        Get klines for SPOT markets (V3 API) - FIXED VERSION
        Uses correct API parameters matching bitmart_history_downloader.py
        BitMart V3 API: before and after are in SECONDS
        Returns candles sorted by timestamp ascending
        """
        endpoint = "/spot/quotation/v3/klines"
        
        # Map timeframe to minutes (as required by 'step' parameter)
        timeframe_to_minutes = {
            # Minutes
            '1min': 1, '1m': 1, 'minute': 1,
            '3min': 3, '3m': 3,
            '4min': 4, '4m': 4,  # Added 4min timeframe
            '5min': 5, '5m': 5,
            '15min': 15, '15m': 15,
            '30min': 30, '30m': 30,
            '36min': 36, '36m': 36,  # Added 36min timeframe
            '78min': 78, '78m': 78,  # Added 78min timeframe
            
            # Hours
            '1hour': 60, '1h': 60, '60min': 60, 'hour': 60,
            '2hour': 120, '2h': 120, '120min': 120,
            '4hour': 240, '4h': 240, '240min': 240,
            '6hour': 360, '6h': 360, '360min': 360,
            '12hour': 720, '12h': 720, '720min': 720,
            
            # Days/Weeks/Months
            '1day': 1440, '1d': 1440, 'daily': 1440,
            '3day': 4320, '3d': 4320,
            '1week': 10080, '1w': 10080, 'weekly': 10080,
            '1month': 43200, '1mn': 43200, 'monthly': 43200,
        }
        
        step_minutes = timeframe_to_minutes.get(timeframe.lower())
        if not step_minutes:
            self.logger.error(f"Unsupported timeframe: {timeframe}")
            self.logger.error(f"Supported: {list(timeframe_to_minutes.keys())}")
            return []
        
        formatted_symbol = symbol.upper().replace('-', '_')
        
        # CORRECT PARAMETERS - matches working downloader
        params = {
            'symbol': formatted_symbol,
            'step': step_minutes,  # KEY FIX: Use 'step', not 'interval'
            'limit': min(limit, 200),
        }
        
        # Add timestamps if provided (in SECONDS)
        if before is not None:
            params['before'] = before  # IN SECONDS
        if after is not None:
            params['after'] = after    # IN SECONDS
            
        self.logger.info(f"📈 Fetching {limit} {timeframe} klines for {formatted_symbol}")
        self.logger.info(f"   Step (minutes): {step_minutes}")
        if before: 
            self.logger.info(f"   Before: {datetime.fromtimestamp(before, tz=timezone.utc)}")
        if after:
            self.logger.info(f"   After: {datetime.fromtimestamp(after, tz=timezone.utc)}")
        
        # Make the API request
        data = self._public_request(endpoint, params)
        
        candles = []
        if isinstance(data, list):
            for kline in data:
                try:
                    # BitMart V3 format: [timestamp_seconds, open, high, low, close, volume, quote_volume]
                    timestamp_seconds = int(kline[0])
                    candle_dt = datetime.fromtimestamp(timestamp_seconds, tz=timezone.utc)
                    
                    candles.append({
                        'timestamp': candle_dt,
                        'open': float(kline[1]),
                        'high': float(kline[2]),
                        'low': float(kline[3]),
                        'close': float(kline[4]),
                        'volume': float(kline[5]),
                        'quote_volume': float(kline[6]) if len(kline) > 6 else 0.0
                    })
                except Exception as e:
                    self.logger.warning(f"Skipping malformed kline: {kline}, error: {e}")
            
            # Sort by timestamp ascending
            candles.sort(key=lambda x: x['timestamp'])
            
            self.logger.info(f"✅ Retrieved {len(candles)} candles")
            if candles:
                self.logger.info(f"   Range: {candles[0]['timestamp']} to {candles[-1]['timestamp']}")
        
        return candles

    def get_historical_klines(self, symbol: str, timeframe: str,
                               start_time: datetime = None, 
                               end_time: datetime = None) -> List[Dict]:
        """
        SIMPLIFIED: Fetch historical klines using forward pagination
        Matches the logic in bitmart_history_downloader.py
        """
        if end_time is None:
            end_time = datetime.now(timezone.utc)
        if start_time is None:
            start_time = end_time - timedelta(days=1)
        
        # Convert to timestamps
        start_ts = int(start_time.timestamp())
        end_ts = int(end_time.timestamp())
        
        self.logger.info(f"📊 Fetching historical data from {start_time} to {end_time}")
        
        # Get step in minutes
        timeframe_to_minutes = {
            '1min': 1, '3min': 3, '4min': 4, '5min': 5, '15min': 15, '30min': 30,
            '36min': 36, '78min': 78, '1hour': 60, '2hour': 120, '4hour': 240, 
            '6hour': 360, '12hour': 720, '1day': 1440, '3day': 4320, 
            '1week': 10080, '1month': 43200,
        }
        
        step_minutes = timeframe_to_minutes.get(timeframe.lower())
        if not step_minutes:
            self.logger.error(f"Unsupported timeframe: {timeframe}")
            return []
        
        step_seconds = step_minutes * 60
        all_candles = []
        cursor = start_ts
        
        while cursor < end_ts:
            # Calculate end for this batch (max 200 candles)
            to_ts = min(cursor + step_seconds * 200, end_ts)
            
            # Fetch batch
            batch_candles = self.get_klines(
                symbol=symbol,
                timeframe=timeframe,
                limit=200,
                after=cursor,    # start of batch
                before=to_ts     # end of batch
            )
            
            if not batch_candles:
                break
            
            # Add to collection
            all_candles.extend(batch_candles)
            
            # Move cursor forward
            if batch_candles:
                last_candle = max(batch_candles, key=lambda x: x['timestamp'])
                cursor = int(last_candle['timestamp'].timestamp()) + step_seconds
            else:
                cursor = to_ts
            
            # Rate limiting
            time.sleep(0.25)
        
        # Remove duplicates and sort
        seen_timestamps = set()
        unique_candles = []
        
        for candle in all_candles:
            ts = int(candle['timestamp'].timestamp())
            if ts not in seen_timestamps:
                seen_timestamps.add(ts)
                unique_candles.append(candle)
        
        unique_candles.sort(key=lambda x: x['timestamp'])
        
        self.logger.info(f"✅ Total: {len(unique_candles)} candles retrieved")
        if unique_candles:
            self.logger.info(f"   Range: {unique_candles[0]['timestamp']} to {unique_candles[-1]['timestamp']}")
        
        return unique_candles

    def get_all_symbols(self) -> List[str]:
        """Get all available trading symbols on BitMart"""
        endpoint = "/spot/v1/symbols"
        data = self._public_request(endpoint)
        
        if isinstance(data, dict) and 'symbols' in data:
            symbols = data.get('symbols', [])
            return symbols
        else:
            self.logger.error(f"Failed to get symbols. Response: {data}")
            return []
    
    def get_order_book(self, symbol: str, limit: int = 10) -> Optional[Dict]:
        """Get order book data"""
        endpoint = "/spot/v1/symbols/book"
        formatted_symbol = symbol.replace('-', '_').upper()
        params = {'symbol': formatted_symbol, 'size': limit}
        
        return self._public_request(endpoint, params)
    
    def get_order_detail(self, order_id: str, symbol: str = "BTC_USDT") -> Optional[Dict]:
        """Get order details by order ID - UPDATED"""
        endpoint = "/spot/v2/order_detail"
        
        params = {
            'orderId': order_id,  # Note: camelCase and different parameter name
            'symbol': symbol.replace('-', '_').upper()
        }
        
        return self._private_request('GET', endpoint, params)

    def cancel_order(self, symbol: str, order_id: str) -> Optional[Dict]:
        """Cancel an open order - UPDATED"""
        endpoint = "/spot/v2/cancel_order"
        
        params = {
            'symbol': symbol.replace('-', '_').upper(),
            'orderId': order_id  # Note: camelCase
        }
        
        return self._private_request('POST', endpoint, params)
    
    # ---------- Account Methods ----------
    def get_account_balance(self) -> Dict:
        """Get account balance - UPDATED endpoint"""
        # Try multiple possible endpoints
        endpoints_to_try = [
            "/account/v2/wallet",      # Most likely current endpoint
            "/account/v1/wallet",      # Alternative
            "/spot/v2/account",        # Another possibility
            "/api/v2/account/wallet",  # Common pattern
        ]
        
        for endpoint in endpoints_to_try:
            self.logger.info(f"Trying balance endpoint: {endpoint}")
            result = self._private_request('GET', endpoint)
            if result is not None:
                self.logger.info(f"✅ Found working balance endpoint: {endpoint}")
                return result
        
        self.logger.error("❌ No balance endpoint worked")
        return {}
    
    # ---------- Order Methods ----------
    def place_order(self, symbol: str, side: str, order_type: str, 
               size: float, price: Optional[float] = None,
               stp_mode: str = "none", client_order_id: str = None) -> Optional[Dict]:
        """
        Place an order on BitMart - CORRECTED based on curl example
        Uses POST /spot/v2/submit_order
        """
        endpoint = "/spot/v2/submit_order"
        
        # Format symbol correctly
        formatted_symbol = symbol.replace('-', '_').upper()
        
        # IMPORTANT: Based on curl example, 'size' is in QUOTE currency (USDT for BTC_USDT)
        # If you want to buy $10 worth of BTC, size=10
        # If you want to buy 0.00011 BTC, you need to convert: size = 0.00011 * price
        
        # Prepare parameters EXACTLY as in curl example
        params = {
            'symbol': formatted_symbol,
            'side': side.lower(),  # 'buy' or 'sell' (lowercase)
            'type': order_type.lower(),  # 'limit' or 'market' (lowercase)
            'size': str(round(size, 8)),  # In QUOTE currency (USDT) for BTC_USDT
            'stpMode': stp_mode.lower() if stp_mode else 'none'  # REQUIRED parameter!
        }
        
        # Add price for limit orders
        if order_type.lower() == 'limit':
            if price is None:
                self.logger.error("Price is required for limit orders")
                return None
            params['price'] = str(round(price, 2))
        
        # Add client order ID if provided (may be optional)
        if client_order_id:
            params['clientOrderId'] = client_order_id
        
        self.logger.info(f"Placing order with CORRECTED params: {params}")
        
        # Use the updated endpoint
        result = self._private_request('POST', endpoint, params)
        
        if result:
            self.logger.info(f"✅ Order placed successfully: {result}")
            return result
        else:
            self.logger.error("❌ Failed to place order")
            return None
        
        # ========== REAL ORDER EXECUTION METHODS ==========
    
    def place_limit_order(self, symbol: str, side: str, quantity: float, price: float, 
                          client_order_id: str = None) -> Optional[Dict]:
        """
        Place a LIMIT order on BitMart
        Returns: {'order_id': '123456', 'client_order_id': 'abc123', 'status': 'filled'}
        """
        endpoint = "/spot/v2/submit_order"
        
        formatted_symbol = symbol.replace('-', '_').upper()
        
        # IMPORTANT: For BTC_USDT pair:
        # - BUY: quantity is in USDT (quote currency) - you want to buy $X worth of BTC
        # - SELL: quantity is in BTC (base currency) - you want to sell X BTC
        
        params = {
            'symbol': formatted_symbol,
            'side': side.lower(),  # 'buy' or 'sell'
            'type': 'limit',
            'size': str(round(quantity, 8)),
            'price': str(round(price, 8)),
            'stpMode': 'none'
        }
        
        if client_order_id:
            params['clientOrderId'] = client_order_id
        
        self.logger.info(f"📝 Placing LIMIT order: {params}")
        
        return self._private_request('POST', endpoint, params)
    
    def place_market_order(self, symbol: str, side: str, quantity: float,
                           client_order_id: str = None) -> Optional[Dict]:
        """
        Place a MARKET order on BitMart
        For BUY: quantity is in USDT (quote currency) - buy $X worth
        For SELL: quantity is in BTC (base currency) - sell X BTC
        """
        endpoint = "/spot/v2/submit_order"
        
        formatted_symbol = symbol.replace('-', '_').upper()
        
        params = {
            'symbol': formatted_symbol,
            'side': side.lower(),
            'type': 'market',
            'size': str(round(quantity, 8)),
            'stpMode': 'none'
        }
        
        if client_order_id:
            params['clientOrderId'] = client_order_id
        
        self.logger.info(f"📝 Placing MARKET order: {params}")
        
        return self._private_request('POST', endpoint, params)
    
    def get_open_orders(self, symbol: str, limit: int) -> Optional[Dict]:
        """
        Get current open orders
        """
        endpoint = "/spot/v2/orders"
        
        params = {}
        if symbol:
            formatted_symbol = symbol.replace('-', '_').upper()
            params['symbol'] = formatted_symbol
        if limit:
            params['limit'] = limit
        
        self.logger.info(f"📋 Getting open orders for {symbol if symbol else 'all symbols'}")
        
        return self._private_request('GET', endpoint, params)
    
    def cancel_all_orders(self, symbol: str) -> Optional[Dict]:
        """
        Cancel ALL open orders for a symbol
        """
        endpoint = "/spot/v1/cancel_orders"
        
        formatted_symbol = symbol.replace('-', '_').upper()
        params = {'symbol': formatted_symbol}
        
        self.logger.info(f"🚫 Cancelling ALL orders for {symbol}")
        
        return self._private_request('POST', endpoint, params)
    
    def get_account_trades(self, symbol: str, limit: int = 100) -> Optional[Dict]:
        """
        Get account trade history
        """
        endpoint = "/spot/v1/trades"
        
        formatted_symbol = symbol.replace('-', '_').upper()
        params = {
            'symbol': formatted_symbol,
            'limit': limit
        }
        
        self.logger.info(f"📊 Getting trade history for {symbol}")
        
        return self._private_request('GET', endpoint, params)
    
    def get_order_history(self, symbol: str, limit: int) -> Optional[Dict]:
        """
        Get order history (filled, cancelled, etc.)
        """
        endpoint = "/spot/v1/history_orders"
        
        formatted_symbol = symbol.replace('-', '_').upper()
        params = {
            'symbol': formatted_symbol,
            'limit': limit
        }
        
        self.logger.info(f"📜 Getting order history for {symbol}")
        
        return self._private_request('GET', endpoint, params)
    
    # Helper for live trading
    def get_current_price(self, symbol: str) -> Optional[float]:
        """
        Get current market price for a symbol
        """
        ticker = self.get_ticker(symbol)
        if ticker:
            return float(ticker.get('last_price', 0))
        return None
    
    # ========== SIMPLIFIED ORDER PLACEMENT ==========
    
    def execute_trade_simple(self, symbol: str, action: str, amount: float, 
                             order_type: str = 'market', price: float = None) -> Dict:
        """
        Simplified trade execution with better error handling
        Returns: {'success': bool, 'order_id': str, 'message': str, 'details': dict}
        """
        result = {
            'success': False,
            'order_id': None,
            'message': '',
            'details': {}
        }
        
        try:
            # Get current price for reference
            current_price = self.get_current_price(symbol)
            
            if order_type.lower() == 'market':
                # Market order
                if action.lower() == 'buy':
                    # For BUY market orders: amount is in USDT
                    order_result = self.place_market_order(symbol, 'buy', amount)
                    result['message'] = f"Market BUY order for ${amount:.2f} worth"
                else:  # sell
                    # For SELL market orders: amount is in base currency (e.g., BTC)
                    order_result = self.place_market_order(symbol, 'sell', amount)
                    result['message'] = f"Market SELL order for {amount} coins"
                    
            elif order_type.lower() == 'limit':
                if price is None:
                    result['message'] = "Price is required for limit orders"
                    return result
                
                # Limit order
                order_result = self.place_limit_order(symbol, action, amount, price)
                result['message'] = f"Limit {action.upper()} order: {amount} @ ${price:.2f}"
                
            else:
                result['message'] = f"Unsupported order type: {order_type}"
                return result
            
            # Process result
            if order_result:
                result['success'] = True
                result['order_id'] = order_result.get('order_id')
                result['details'] = order_result
                
                # Log successful order
                self.logger.info(f"✅ Order placed successfully: {result['message']}")
                self.logger.info(f"   Order ID: {result['order_id']}")
                
                if current_price:
                    self.logger.info(f"   Current price: ${current_price:.2f}")
            else:
                result['message'] = "Order placement failed (no response from API)"
                
        except Exception as e:
            result['message'] = f"Order execution error: {str(e)}"
            self.logger.error(f"❌ Trade execution failed: {e}")
        
        return result
    
    
# ---------- Test Functions ----------
def test_bitmart_connection():
    """Test BitMart API connection"""
    print("Testing BitMart REST API connection...")
    try:
        client = BitMartRESTClient()
        symbols = client.get_all_symbols()

        if isinstance(symbols, list) and symbols:
            print(f"✅ Connection successful")
            print(f"Total symbols available: {len(symbols)}")
            popular_symbols = [s for s in symbols if 'USDT' in s][:10]
            print(f"Sample symbols: {', '.join(popular_symbols[:5])}...")
            return True
        else:
            print(f"❌ Connection failed: No symbols retrieved.")
            return False

    except Exception as e:
        print(f"❌ Connection failed: {e}")
        return False

def test_bitmart_data_fetch(symbol: str = "BTC_USDT"):
    """Test data fetching from BitMart"""
    print(f"Testing data fetch for {symbol}...")
    
    try:
        client = BitMartRESTClient()
        
        # Get ticker
        ticker = client.get_ticker(symbol)
        if ticker:
            print(f"✅ Ticker data:")
            print(f"   Last Price: ${float(ticker.get('last_price', 0)):.2f}")
            print(f"   24h Volume: {float(ticker.get('base_volume', 0)):.2f}")
        
        # Get klines
        candles = client.get_klines(symbol, "5min", limit=5)
        if candles:
            print(f"✅ Latest candles:")
            for candle in candles[-3:]:
                timestamp = candle['timestamp'].strftime('%H:%M')
                print(f"   {timestamp}: O:{candle['open']:.2f} H:{candle['high']:.2f} "
                      f"L:{candle['low']:.2f} C:{candle['close']:.2f}")
        
        return True
    except Exception as e:
        print(f"❌ Data fetch failed: {e}")
        return False
    


# ---------- Main Function ----------
if __name__ == "__main__":
    print("BitMart REST API Module (No SDK Required)")
    print("=" * 50)
    
    # Test connection
    test_bitmart_connection()
    
    # Test data fetch
    test_bitmart_data_fetch()

    
    print("\nModule ready for use!")