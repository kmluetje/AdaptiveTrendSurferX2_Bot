import numpy as np
from collections import deque
import logging
from datetime import datetime, timedelta, timezone
import math
from typing import Dict, List, Optional, Tuple

import pytz

class AdaptiveTrendSurferX2:
    

    def __init__(self, config: Dict):
        # ========== STRATEGY PARAMETERS ==========
        self.initial_cash = config['initial_cash']
        self.trade_qty = config['trade_qty']
        
        self.improve_Profit = config.get('improve_Profit')
        # Strategy direction
        self.enable_long = config['enable_long']
        self.enable_short = config['enable_short']
        
        # Sideways filter
        self.use_sideways_filter = config['use_sideways_filter']
        self.sideways_length = config['sideways_length']
        self.sideways_std_dev = config['sideways_std_dev']
        self.sideways_atr_mult = config['sideways_atr_mult']
        
        # TSI thresholds
        self.long_threshold = config['long_threshold']
        self.short_threshold = config['short_threshold']
        self.exit_delay_long = config['exit_delay_long'] + 1
        self.exit_delay_short = config['exit_delay_short'] + 1
        
        # Take profit settings
        self.tp_type_long = config['tp_type_long']
        self.tp_type_short = config['tp_type_short']
        self.tp_val_long = config['tp_val_long']
        self.tp_val_short = config['tp_val_short']
        self.tp1_qty_long_pct = max(1, min(config['tp1_qty_long_pct'], 100))
        self.tp1_qty_short_pct = max(1, min(config['tp1_qty_short_pct'], 100))
        self.use_price_based_dynamic_exit_long = config['use_price_based_dynamic_exit_long']
        self.price_exit_threshold_long = config['price_exit_threshold_long']
        self.use_price_based_dynamic_exit_short = config['use_price_based_dynamic_exit_short']
        self.price_exit_threshold_short = config['price_exit_threshold_short']
        
        # Risk management
        self.use_trailing_stop = config['use_trailing_stop']
        self.use_hard_stop = config['use_hard_stop']
        self.enable_bar_close_stop_exit = config['enable_bar_close_stop_exit']
        self.ts_atr_length = config['ts_atr_length']
        self.ts_atr_mult = config['ts_atr_mult']
        self.use_min_tsl_distance = config['use_min_tsl_distance']
        self.min_tsl_distance_ticks = config['min_tsl_distance_ticks']
        self.hard_stop_atr_mult = config['hard_stop_atr_mult']
        self.ts_activation_mode_long = config['ts_activation_mode_long']
        self.ts_activation_mode_short = config['ts_activation_mode_short']
        
        # TSI parameters
        self.mabars = config['mabars']
        self.smoothed = config['smoothed']
        self.raw = config['raw']
        self.u_tsi = config['u_tsi']
        self.plen_combo = config['plen_combo']

        self.enable_trading = True  
        self.trading_start_date = None
        self.trading_end_date = None
        
        if 'start_date' in config and config['start_date']:
            try:
                # ADD .replace(tzinfo=timezone.utc) to make it timezone-aware
                self.trading_start_date = datetime.strptime(config['start_date'], "%Y-%m-%d").replace(tzinfo=timezone.utc)
                print(f"🎯 Trading will start from: {self.trading_start_date}")
            except Exception as e:
                print(f"⚠️ Error parsing start_date: {e}")

        if 'end_date' in config and config['end_date']:
            try:
                # ADD .replace(tzinfo=timezone.utc) to make it timezone-aware
                self.trading_end_date = datetime.strptime(config['end_date'], "%Y-%m-%d").replace(tzinfo=timezone.utc) + timedelta(days=1)
                print(f"🎯 Trading will end at: {self.trading_end_date}")
            except Exception as e:
                print(f"⚠️ Error parsing end_date: {e}")

        # ========== TRADING SCHEDULE ==========
        self.trading_schedule = config.get('trading_schedule', {})
        self.trading_schedule_active = self.trading_schedule.get('active', False)
        
        if self.trading_schedule_active:
            # Parse trading schedule
            self.start_day = self.trading_schedule['start']['day']
            self.start_time_str = self.trading_schedule['start']['time']
            self.end_day = self.trading_schedule['end']['day']
            self.end_time_str = self.trading_schedule['end']['time']
            self.schedule_timezone = pytz.timezone(self.trading_schedule.get('timezone', 'UTC'))
            
            # Parse times
            self.start_hour, self.start_minute = map(int, self.start_time_str.split(':'))
            self.end_hour, self.end_minute = map(int, self.end_time_str.split(':'))
            
            # Convert day names to numbers (0=Monday, 6=Sunday in Python)
            self.day_map = {
                "Monday": 0, "Tuesday": 1, "Wednesday": 2, 
                "Thursday": 3, "Friday": 4, "Saturday": 5, "Sunday": 6
            }
            self.start_day_num = self.day_map[self.start_day]
            self.end_day_num = self.day_map[self.end_day]
            
            # Parse trading breaks if any
            self.trading_breaks = self.trading_schedule.get('trading_breaks', [])
            
            
        # ========== STATE VARIABLES (like Pine Script var) ==========
        self.cash = self.initial_cash
        self.positions = 0
        self.entry_price = 0.0
        self.entry_time = None

        self.prev_high = 0.0
        self.prev_low = 0.0
        
        # TSI state
        self.m_bFirst = True
        self.m_tsi = 0.0
        self.m_tsiMA = 0.0
        self.m_xavg1 = 0.0
        self.m_xavg2 = 0.0
        self.m_xavg3 = 0.0
        self.m_axavg1 = 0.0
        self.m_axavg2 = 0.0
        self.m_axavg3 = 0.0
        self.prev_close = None
        self.prev_low = None
        self.prev_high = None
        
        # Position state
        self.dir = 0
        self.longEntry = 0.0
        self.longTP = 0.0
        self.shortEntry = 0.0
        self.shortTP = 0.0
        self.dynamicTp1Taken_L = False
        self.dynamicTp1Taken_S = False
        self.percentageTp1Taken_L = False
        self.percentageTp1Taken_S = False
        self.trailStopLevel_L = 0.0
        self.trailStopLevel_S = 0.0
        self.tsl_active_L = False
        self.tsl_active_S = False
        self.hard_stop_long = 0.0
        self.hard_stop_short = 0.0

        self.L_Signal = True
        self.S_Signal = True
        self.prev_trailStopLevel_L = 0.0
        self.prev_trailStopLevel_S = 0.0
        
        # Peak detection
        self.magenta = None
        self.ptsi_combo = 0.0
        self.m_bIsPeak_combo = False
        self.peak_combo_values = deque(maxlen=self.plen_combo)
        
        self.custom_atr_values = deque(maxlen=200)
        # Data windows
        self.true_ranges = deque(maxlen=200)
        self.high_window = deque(maxlen=200)
        self.low_window = deque(maxlen=200)
        self.close_window = deque(maxlen=200)
        self.open_window = deque(maxlen=200)
        self.side_ohlc4 = deque(maxlen=200)
        
        # Delay counters
        self.bs_long = 10**9
        self.bs_short = 10**9
        self.last_above_ma_bar = -10**9
        self.last_below_ma_bar = -10**9
        
        # Trade tracking
        self.trades = []
        self.trade_counter = 0
        self.current_bar = 0

        # Previous values for crossover detection
        self.prev_tsi = None
        self.prev_tsi_ma = None

        self.equity_curve = []  
        self.peak_equity = self.initial_cash
        
        # ATR
        self.atrTS = 0.0
        
        # Logging
        self.setup_logging()

        if self.trading_schedule_active:
            self.logger.info(f"🕒 Trading Schedule Active: {self.start_day} {self.start_time_str} to {self.end_day} {self.end_time_str} ({self.schedule_timezone})")

    def setup_logging(self):
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger(__name__)

    # ========== CORE PINE SCRIPT FUNCTIONS ==========
    
    def xavg(self, p: float, length: int, prevxavg: float) -> float:
        """Exact Pine Script xavg function"""
        alpha = 2.0 / (float(length) + 1)
        if prevxavg == 0.0 and self.m_bFirst:  
            return p
        else:
            return alpha * p + (1 - alpha) * prevxavg

    def calculate_true_range(self, high: float, low: float, prev_close: float) -> float:
        """Standard True Range that ta.atr() uses internally"""
        if prev_close is None:
            return high - low
        
        tr1 = high - low
        tr2 = abs(high - prev_close)
        tr3 = abs(low - prev_close)
        return max(tr1, tr2, tr3)

    def average_dev(self, serie_in: List[float], length: int) -> Tuple[float, float]:
        """Pine Script AverageDev function"""
        if length <= 0 or not serie_in or len(serie_in) < length:
            return (float('nan'), float('nan'))
        
        avgret = sum(serie_in[-length:]) / length
        sumsq = 0.0
        
        for i in range(length):
            vv = serie_in[-(i+1)] - avgret
            sumsq += vv * vv
        sumsq /= length
        devret = math.sqrt(sumsq)
        
        return (avgret, devret)

    def waverage(self, serie_in: List[float], length: int) -> float:
        """Pine Script WAverage function"""
        if length <= 0 or len(serie_in) < length:
            return float('nan')
            
        sum_w = 0.0
        weight_sum = 0.0
        
        for i in range(length):
            weight = float(length - i)
            sum_w += serie_in[-(i+1)] * weight
            weight_sum += weight
            
        return sum_w / weight_sum if weight_sum != 0 else float('nan')
    
    def calculate_custom_atr(self, high: float, low: float, prev_close: float) -> float:
        """Custom ATR-like calculation from Pine Script"""
        if prev_close is None:
            return high - low
        
        th = prev_close if prev_close > high else high
        tl = prev_close if prev_close < low else low
        return th - tl

    # ========== INDICATOR CALCULATIONS ==========

    def calculate_tsi(self, close: float):
        """EXACT Pine Script TSI Calculation - FIXED first bar"""
        if self.prev_close is None:
            self.prev_close = close
            return
            
        netChg_calc = close - self.prev_close
        anetChg_calc = abs(netChg_calc)
        
        if self.m_bFirst:
            # First bar initialization (EXACT Pine Script logic)
            self.m_bFirst = False
            
            # For first bar, xavg uses current value as both input and previous
            self.m_xavg1 = netChg_calc  
            self.m_xavg2 = self.m_xavg1 
            self.m_xavg3 = self.m_xavg2 
            
            self.m_axavg1 = anetChg_calc  
            self.m_axavg2 = self.m_axavg1 
            self.m_axavg3 = self.m_axavg2 
            
            # First TSI value
            v1_calc = 100.0 * self.m_xavg3
            v2_calc = self.m_axavg3
            self.m_tsi = 0.0 if v2_calc == 0.0 else v1_calc / v2_calc
            self.m_tsiMA = self.m_tsi  # First MA value = first TSI value
            
        else:
            # Subsequent bars - use normal xavg calculation
            self.m_xavg1 = self.xavg(netChg_calc, self.raw, self.m_xavg1)
            self.m_xavg2 = self.xavg(self.m_xavg1, self.smoothed, self.m_xavg2)
            self.m_xavg3 = self.xavg(self.m_xavg2, self.u_tsi, self.m_xavg3)
            self.m_axavg1 = self.xavg(anetChg_calc, self.raw, self.m_axavg1)
            self.m_axavg2 = self.xavg(self.m_axavg1, self.smoothed, self.m_axavg2)
            self.m_axavg3 = self.xavg(self.m_axavg2, self.u_tsi, self.m_axavg3)
            
            # Calculate TSI value
            v1_calc = 100.0 * self.m_xavg3
            v2_calc = self.m_axavg3
            self.m_tsi = 0.0 if v2_calc == 0.0 else v1_calc / v2_calc
            
            # Calculate TSI MA
            self.m_tsiMA = self.xavg(self.m_tsi, self.mabars, self.m_tsiMA)

    def calculate_atr(self) -> float:
        """EXACT TradingView ta.atr() calculation - 100% match"""
        length = self.ts_atr_length  # This is 10
        
        if len(self.true_ranges) < length:
            return 0.0
        
        # TradingView's exact ATR logic:
        # For the first 'length' periods, it uses a simple average
        # For subsequent periods, it uses RMA smoothing
        
        if not hasattr(self, '_atr_initialized'):
            # First time we have enough data - use SMA
            if len(self.true_ranges) == length:
                initial_tr = list(self.true_ranges)
                self._atr_rma = sum(initial_tr) / length
                self._atr_initialized = True
                return self._atr_rma
            else:
                return 0.0
        
        # For all subsequent bars, use RMA
        current_tr = self.true_ranges[-1]
        alpha = 1.0 / length  # RMA alpha factor
        new_atr = (current_tr * alpha) + (self._atr_rma * (1 - alpha))
        self._atr_rma = round(new_atr, 2)
        return self._atr_rma

    def calculate_sideways_market(self) -> bool:
        """Pine Script SidewayCalc function"""
        if not self.use_sideways_filter:
            return False
            
        if len(self.side_ohlc4) < self.sideways_length:
            return False
        
        m_bPrice = list(self.side_ohlc4)
        bavg, bdev = self.average_dev(m_bPrice, self.sideways_length)
        
        if math.isnan(bavg) or math.isnan(bdev):
            return False
            
        bup = bavg + self.sideways_std_dev * bdev
        blow = bavg - self.sideways_std_dev * bdev
        
        kavg = sum(m_bPrice[-self.sideways_length:]) / self.sideways_length
        
        if len(self.custom_atr_values) < self.sideways_length:
            return False
            
        atr_avg = sum(list(self.custom_atr_values)[-self.sideways_length:]) / self.sideways_length
        shift = self.sideways_atr_mult * atr_avg
        kup = kavg + shift
        klow = kavg - shift
        
        return bup <= kup and blow >= klow

    def calculate_peak_detection(self, high: float, low: float):
        """COMPLETE Pine Script Peak/Combo Logic"""
        if len(self.high_window) < self.plen_combo or len(self.low_window) < self.plen_combo:
            self.m_bIsPeak_combo = False
            self.magenta = None
            self.logger.info(f"MAGENTA_DEBUG - Insufficient data: highs={len(self.high_window)}, lows={len(self.low_window)}, need={self.plen_combo}")
            return
        
        # Calculate ATR for peak detection
        if len(self.true_ranges) >= self.plen_combo:
            atr_val_combo = sum(list(self.custom_atr_values)[-self.plen_combo:]) / self.plen_combo
        else:
            atr_val_combo = 1.0
        
        slen_sqrt_combo = math.sqrt(float(self.plen_combo))
        
        # Get previous high/low (like Pine Script nz(low[plen_combo]))
        prev_low = self.low_window[-self.plen_combo] if len(self.low_window) >= self.plen_combo else low
        prev_high = self.high_window[-self.plen_combo] if len(self.high_window) >= self.plen_combo else high
        
        rwh_combo = (high - prev_low) / (atr_val_combo * slen_sqrt_combo) if atr_val_combo != 0 else 0.0
        rwl_combo = (prev_high - low) / (atr_val_combo * slen_sqrt_combo) if atr_val_combo != 0 else 0.0
        
        m_pw_combo = rwh_combo - rwl_combo
        
        # Calculate weighted average (like Pine Script WAverage(m_pw_combo, 3))
        peak_values = list(self.peak_combo_values)
        if len(peak_values) >= 2:
            recent_peaks = peak_values[-2:] + [m_pw_combo]
            p0_combo = self.waverage(recent_peaks, 3)
        else:
            p0_combo = m_pw_combo
        
        if math.isnan(p0_combo):
            p0_combo = m_pw_combo
        
        self.peak_combo_values.append(p0_combo)
        
        # Calculate average and deviation
        pavg_combo, pdev_combo = self.average_dev(list(self.peak_combo_values), self.plen_combo)
        
        if math.isnan(pavg_combo) or math.isnan(pdev_combo):
            v1_peak_combo = 2.08
            v2_peak_combo = -1.92
        else:
            v1_peak_combo = max(2.08, pavg_combo + 1.33 * pdev_combo)
            v2_peak_combo = min(-1.92, pavg_combo - 1.33 * pdev_combo)
        
        p1_combo = self.ptsi_combo

        self.logger.info(f"PEAK_CALC - ATR:{atr_val_combo:.4f} rwh:{rwh_combo:.4f} rwl:{rwl_combo:.4f}")
        self.logger.info(f"PEAK_CALC - m_pw:{m_pw_combo:.4f} p0:{p0_combo:.4f} p1:{p1_combo:.4f}")
        self.logger.info(f"PEAK_CALC - pavg:{pavg_combo:.4f} pdev:{pdev_combo:.4f}")
        self.logger.info(f"PEAK_CALC - v1:{v1_peak_combo:.4f} v2:{v2_peak_combo:.4f}")
        
        # Peak conditions (EXACT Pine Script logic)
        peak_condition_positive = (p0_combo > 0.0) and (p0_combo > p1_combo) and (p0_combo > v1_peak_combo)
        peak_condition_negative = (p0_combo < 0.0) and (p0_combo < p1_combo) and (p0_combo < v2_peak_combo)
        
        self.logger.info(f"PEAK_CONDITIONS - Positive: {peak_condition_positive}")
        self.logger.info(f"PEAK_CONDITIONS - p0>0: {p0_combo > 0.0} p0>p1: {p0_combo > p1_combo} p0>v1: {p0_combo > v1_peak_combo}")
        self.logger.info(f"PEAK_CONDITIONS - Negative: {peak_condition_negative}") 
        self.logger.info(f"PEAK_CONDITIONS - p0<0: {p0_combo < 0.0} p0<p1: {p0_combo < p1_combo} p0<v2: {p0_combo < v2_peak_combo}")
            
        self.m_bIsPeak_combo = (not math.isnan(p0_combo) and not math.isnan(p1_combo) and 
                               not math.isnan(v1_peak_combo) and not math.isnan(v2_peak_combo) and
                               (peak_condition_positive or peak_condition_negative))
        
        self.logger.info(f"m_bIsPeak_combo : {self.m_bIsPeak_combo}")
        
        # Magenta signal logic (EXACT Pine Script)
        if self.m_bIsPeak_combo:
            self.logger.info(f"tsi : {self.m_tsi}")
            self.magenta = self.m_tsi
        else:
            self.magenta = None
        
        self.ptsi_combo = p0_combo

    def update_delay_counters(self):
        """EXACT Pine Script barssince logic"""
        # aboveMA_plot := m_tsi >= m_tsiMA ? m_tsi : na
        # bs_L = ta.barssince(not na(aboveMA_plot))
        
        if self.m_tsi >= self.m_tsiMA:
            self.last_above_ma_bar = self.current_bar
        
        if self.last_above_ma_bar >= 0:
            self.bs_long = self.current_bar - self.last_above_ma_bar
        else:
            self.bs_long = 10**9
        
        # belowMA_plot := m_tsi < m_tsiMA ? m_tsi : na  
        # bs_S = ta.barssince(not na(belowMA_plot))
        
        if self.m_tsi < self.m_tsiMA:
            self.last_below_ma_bar = self.current_bar
        
        if self.last_below_ma_bar >= 0:
            self.bs_short = self.current_bar - self.last_below_ma_bar
        else:
            self.bs_short = 10**9

    def get_final_tsl_offset(self) -> float:
        """Pine Script getFinalTslOffset function"""
        
        calculatedAtrOffset = self.atrTS * self.ts_atr_mult
        minPriceOffset = self.min_tsl_distance_ticks * 0.01
        
        if self.use_min_tsl_distance:
            return round(max(calculatedAtrOffset, minPriceOffset), 2)
        else:
            return round(calculatedAtrOffset, 2)

    # ========== ENTRY/EXIT LOGIC ==========
    def is_within_trading_hours(self, timestamp: datetime) -> bool:
        """
        Universal trading hours check using minutes calculation
        Works with ANY day/time combination in config
        """
        if not self.trading_schedule_active:
            return True
        
        try:
            if timestamp.tzinfo is None:
                localized_time = pytz.utc.localize(timestamp).astimezone(self.schedule_timezone)
            else:
                localized_time = timestamp.astimezone(self.schedule_timezone)
        except Exception as e:
            self.logger.error(f"Timezone error: {e}")
            return False
        
        # Calculate minutes since Monday 00:00
        current_day_num = localized_time.weekday()  # 0=Monday, 6=Sunday
        current_total_minutes = (current_day_num * 24 * 60) + \
                            (localized_time.hour * 60) + \
                            localized_time.minute
        
        # Get config values (already parsed in __init__)
        start_day_num = self.day_map.get(self.start_day, 0)
        end_day_num = self.day_map.get(self.end_day, 4)
        
        start_total_minutes = (start_day_num * 24 * 60) + \
                            (self.start_hour * 60) + self.start_minute
        end_total_minutes = (end_day_num * 24 * 60) + \
                        (self.end_hour * 60) + self.end_minute
        
        # DEBUG: Uncomment to see calculations
        # self.logger.debug(f"Current: {current_total_minutes}, Start: {start_total_minutes}, End: {end_total_minutes}")
        
        # Handle week wrap-around (e.g., Sunday to Saturday)
        if end_total_minutes < start_total_minutes:
            # Trading window wraps to next week
            end_total_minutes += 7 * 24 * 60  # Add a week (10080 minutes)
            
            # Adjust current time if we're in the early part of week
            current_adjusted = current_total_minutes
            if current_total_minutes < start_total_minutes:
                current_adjusted += 7 * 24 * 60
            
            return start_total_minutes <= current_adjusted <= end_total_minutes
        else:
            # Normal window within same week
            return start_total_minutes <= current_total_minutes <= end_total_minutes
        
    
    def execute_long_entry(self, close: float, timestamp: datetime):
        """Execute long entry with all Pine Script logic"""
        self.dir = 1
        self.longEntry = close
        self.longTP = self.longEntry * (1 + self.tp_val_long / 100)
        
        # Reset ALL stop levels
        self.dynamicTp1Taken_L = False
        self.percentageTp1Taken_L = False
        self.trailStopLevel_L = 0.0
        self.prev_trailStopLevel_L = 0.0 
        self.tsl_active_L = False
        
        # TSL activation
        if self.use_trailing_stop and self.ts_activation_mode_long == "Immediate":
            self.tsl_active_L = True
            actualOffset = self.get_final_tsl_offset()
            self.trailStopLevel_L = round(self.longEntry - actualOffset, 2)
            self.logger.info(f"🛡️ Initial Long Stop: {self.longEntry:.1f} - {actualOffset:.1f} = {self.trailStopLevel_L:.1f}")
        
        # Hard stop
        if self.use_hard_stop:
            self.hard_stop_long = self.longEntry - (self.atrTS * self.hard_stop_atr_mult)
        
        self.enter_long(close, timestamp)
        self.logger.info(f"{timestamp} LONG ENTRY: {close:.2f}, TSI: {self.m_tsi:.2f}")

    def execute_short_entry(self, close: float, timestamp: datetime):
        """Execute short entry with all Pine Script logic"""
        self.dir = -1
        self.shortEntry = close
        self.shortTP = self.shortEntry * (1 - self.tp_val_short / 100)
        
        # Reset ALL stop levels
        self.dynamicTp1Taken_S = False
        self.percentageTp1Taken_S = False
        self.trailStopLevel_S = 0.0
        self.prev_trailStopLevel_S = 0.0  
        self.tsl_active_S = False
        
        # TSL activation
        if self.use_trailing_stop and self.ts_activation_mode_short == "Immediate":
            self.tsl_active_S = True
            actualOffset = self.get_final_tsl_offset()
            self.trailStopLevel_S = round(self.shortEntry + actualOffset, 2)
            self.logger.info(f"🛡️ Initial Short Stop: {self.shortEntry:.1f} + {actualOffset:.1f} = {self.trailStopLevel_S:.1f}")
        
        # Hard stop
        if self.use_hard_stop:
            self.hard_stop_short = self.shortEntry + (self.atrTS * self.hard_stop_atr_mult)
        
        self.enter_short(close, timestamp)
        self.logger.info(f"SHORT ENTRY: {close:.2f}, TSI: {self.m_tsi:.2f}")

    def check_exits(self, high: float, low: float, close: float, timestamp: datetime):
        """COMPLETE Pine Script Exit Logic in EXACT order"""
        
        # Track if position was closed to maintain correct execution order
        position_closed = False
        
        # 1. Bar Close Stops
        if self.enable_bar_close_stop_exit and not position_closed:
            self.check_bar_close_stops(high, low, close, timestamp)
            position_closed = (self.positions == 0)
            if position_closed:
                self.logger.info("✅ Position closed via Bar Close Stop")
                return  # Stop checking other exits
        
        # 2. Percentage TP - FIXED LOGGING
        if not position_closed:
            # Store position before checking TP
            positions_before = self.positions
            self.check_percentage_tp(high, low, close, timestamp)
            position_closed = (self.positions == 0)
            if position_closed and positions_before != 0:
                self.logger.info("✅ Position closed via Percentage TP")
                return  # Stop checking other exits
            else:
                self.logger.info(f"📊 Percentage TP Check - High: {high:.1f}, LongTP: {self.longTP:.1f}, Condition: {high >= self.longTP}")
        
        # 3. Magenta Signal (Phase Transition) - Doesn't close position
        if not position_closed:
            self.logger.info(f" no position close dir :{self.dir} megenta : {self.magenta}")
            if self.dir == 1 and self.magenta is not None:
                self.dir = 2
                self.logger.info("🔄 PHASE TRANSITION: Long -> Dynamic")
            if self.dir == -1 and self.magenta is not None:
                self.dir = -2
                self.logger.info("🔄 PHASE TRANSITION: Short -> Dynamic")
        
        # 4. Zero Cross Exits
        if not position_closed:
            # Store position before checking zero cross
            positions_before = self.positions
            self.check_zero_cross_exits(close, timestamp)
            position_closed = (self.positions == 0)
            if position_closed and positions_before != 0:
                self.logger.info("✅ Position closed via Zero Cross")
                return  # Stop checking other exits
            else:
                self.logger.info(f"📊 Zero Cross Check - TSI: {self.m_tsi:.2f}, Prev TSI: {self.prev_tsi:.2f}")
        
        # 5. Dynamic TP Exits
        if not position_closed:
            # Store position before checking dynamic TP
            positions_before = self.positions
            self.check_dynamic_tp_exits(high, low, close, timestamp)
            position_closed = (self.positions == 0)
            # self.logger.info(f"position_closed : {position_closed}  positions_before : {positions_before}")
            if position_closed and positions_before != 0:
                self.logger.info("✅ Position closed via Dynamic TP")
                return  # Stop checking other exits
            else:
                self.logger.info(f"📊 Dynamic TP Check - bs_long: {self.bs_long}, exit_delay: {self.exit_delay_long}")
        
        # 6. Trailing Stop Execution (Continuous)
        if not position_closed:
            # Store position before checking trailing stops
            positions_before = self.positions
            self.update_trailing_stops(high, low, close, timestamp)
            if self.positions == 0 and positions_before != 0:
                self.logger.info("✅ Position closed via Trailing Stop")

    def check_bar_close_stops(self, high: float, low: float, close: float, timestamp: datetime):
        """Bar Close Stop Logic - EXACT Pine Script conditions"""
        if self.positions > 0:
            # Hard Stop Long: low <= longEntry - (atrTS * hardStopAtrMult)
            if (self.use_hard_stop and self.hard_stop_long > 0 and 
                low <= self.hard_stop_long):
                # Pine Script uses strategy.close() - fills at close price
                self.exit_long(close, timestamp, "Hard SL (Bar Close)")
                return
                
            # Trailing Stop Long: tsl_active_L and low <= trailStopLevel_L
            elif (self.use_trailing_stop and self.tsl_active_L and 
                  self.trailStopLevel_L > 0 and low <= self.trailStopLevel_L):
                # Pine Script uses strategy.close() - fills at close price
                self.exit_long(close, timestamp, "TSL (Bar Close)")
                return
        
        if self.positions < 0:
            # Hard Stop Short: high >= shortEntry + (atrTS * hardStopAtrMult)
            if (self.use_hard_stop and self.hard_stop_short > 0 and 
                high >= self.hard_stop_short):
                # Pine Script uses strategy.close() - fills at close price
                self.exit_short(close, timestamp, "Hard SL (Bar Close)")
                return
                
            # Trailing Stop Short: tsl_active_S and high >= trailStopLevel_S
            elif (self.use_trailing_stop and self.tsl_active_S and 
                  self.trailStopLevel_S > 0 and high >= self.trailStopLevel_S):
                # Pine Script uses strategy.close() - fills at close price
                self.exit_short(close, timestamp, "TSL (Bar Close)")
                return

    def check_percentage_tp(self, high: float, low: float, close: float, timestamp: datetime):
        """Percentage TP Logic - EXACT Pine Script conditions"""
        if self.positions > 0 and self.tp_type_long == "Percentage":
            # Percentage TP Long: dir == 1 and high >= longTP
            if (self.dir == 1 and not self.percentageTp1Taken_L and 
                self.longTP > 0 and high >= self.longTP):
                
                if self.tp1_qty_long_pct < 100:
                    # Partial exit - Pine Script uses strategy.close(qty_percent)
                    # Fills at TP price (limit order behavior)
                    self.exit_long_partial(self.longTP, timestamp, self.tp1_qty_long_pct, "Pct TP1 L")
                    self.percentageTp1Taken_L = True
                    
                    # TSL activation after percentage TP1
                    if (self.use_trailing_stop and 
                        self.ts_activation_mode_long == "After Percentage TP1" and 
                        not self.tsl_active_L):
                        self.tsl_active_L = True
                        actualOffset = self.get_final_tsl_offset()
                        self.trailStopLevel_L = round(high - actualOffset, 2)
                else:
                    # Full exit
                    self.exit_long(self.longTP, timestamp, "Pct TP Full L")
                    # Reset state as per Pine Script
                    self.dir = 0
                    self.percentageTp1Taken_L = False
                    self.dynamicTp1Taken_L = False
                    self.trailStopLevel_L = 0.0
                    self.tsl_active_L = False
        
        if self.positions < 0 and self.tp_type_short == "Percentage":
            # Percentage TP Short: dir == -1 and low <= shortTP
            if (self.dir == -1 and not self.percentageTp1Taken_S and 
                self.shortTP > 0 and low <= self.shortTP):
                
                if self.tp1_qty_short_pct < 100:
                    # Partial exit
                    self.exit_short_partial(self.shortTP, timestamp, self.tp1_qty_short_pct, "Pct TP1 S")
                    self.percentageTp1Taken_S = True
                    
                    # TSL activation after percentage TP1
                    if (self.use_trailing_stop and 
                        self.ts_activation_mode_short == "After Percentage TP1" and 
                        not self.tsl_active_S):
                        self.tsl_active_S = True
                        actualOffset = self.get_final_tsl_offset()
                        self.trailStopLevel_S = round(low + actualOffset, 2)
                else:
                    # Full exit
                    self.exit_short(self.shortTP, timestamp, "Pct TP Full S")
                    # Reset state as per Pine Script
                    self.dir = 0
                    self.percentageTp1Taken_S = False
                    self.dynamicTp1Taken_S = False
                    self.trailStopLevel_S = 0.0
                    self.tsl_active_S = False

    def check_zero_cross_exits(self, close: float, timestamp: datetime):
        """Zero Cross Exit Logic - EXACT Pine Script conditions"""
        if self.prev_tsi is None:
            return
            
        # Long exit: ta.crossunder(m_tsi, 0) - strategy.close() fills at close
        if (self.positions > 0 and 
            self.prev_tsi >= 0 and self.m_tsi < 0):
            self.exit_long(close, timestamp, "TSI Zero Cross L")
            # Reset state as per Pine Script
            self.dir = 0
            self.dynamicTp1Taken_L = False
            self.percentageTp1Taken_L = False
            self.trailStopLevel_L = 0.0
            self.tsl_active_L = False
        
        # Short exit: ta.crossover(m_tsi, 0) - strategy.close() fills at close
        elif (self.positions < 0 and 
              self.prev_tsi <= 0 and self.m_tsi > 0):
            self.exit_short(close, timestamp, "TSI Zero Cross S")
            # Reset state as per Pine Script
            self.dir = 0
            self.dynamicTp1Taken_S = False
            self.percentageTp1Taken_S = False
            self.trailStopLevel_S = 0.0
            self.tsl_active_S = False

    def check_dynamic_tp_exits(self, high: float, low: float, close: float, timestamp: datetime):
        """Dynamic TP Logic - EXACT Pine Script conditions"""
        priceTargetReachedL = (self.use_price_based_dynamic_exit_long and 
                              self.longEntry > 0 and 
                              high >= self.longEntry * (1 + self.price_exit_threshold_long / 100))
        
        delayConditionMetL = (self.bs_long == self.exit_delay_long)
        
        priceTargetReachedS = (self.use_price_based_dynamic_exit_short and 
                              self.shortEntry > 0 and 
                              low <= self.shortEntry * (1 - self.price_exit_threshold_short / 100))
        
        delayConditionMetS = (self.bs_short == self.exit_delay_short)

        self.logger.info(f"DynamicTP - Pos:{self.positions} Dir:{self.dir} LongEntry:{self.longEntry:.2f} ShortEntry:{self.shortEntry:.2f}")
        self.logger.info(f"DynamicTP - PriceTargetL:{priceTargetReachedL} DelayMetL:{delayConditionMetL} bs_long:{self.bs_long} exit_delay:{self.exit_delay_long}")
        self.logger.info(f"DynamicTP - PriceTargetS:{priceTargetReachedS} DelayMetS:{delayConditionMetS} bs_short:{self.bs_short} exit_delay:{self.exit_delay_short}")
        self.logger.info(f"DynamicTP - TPLong:{self.tp_type_long} TPShort:{self.tp_type_short} QtyLong:{self.tp1_qty_long_pct} QtyShort:{self.tp1_qty_short_pct}")
        self.logger.info(f"DynamicTP - DynTakenL:{self.dynamicTp1Taken_L} DynTakenS:{self.dynamicTp1Taken_S} PercTakenL:{self.percentageTp1Taken_L} PercTakenS:{self.percentageTp1Taken_S}")
            
        # Long Dynamic Exit
        if self.positions > 0 and self.dir == 2 and (priceTargetReachedL or delayConditionMetL):
            if self.tp_type_long == "Percentage" and self.percentageTp1Taken_L:
                # Dynamic exit of percentage remainder - fills at close
                self.exit_long(close, timestamp, "Dyn Exit of Pct Rem L")
                # Reset state
                self.dir = 0
                self.dynamicTp1Taken_L = False
                self.percentageTp1Taken_L = False
                self.trailStopLevel_L = 0.0
                self.tsl_active_L = False
                
            elif self.tp_type_long == "Dynamic":
                self.logger.info(f"DynamicTP - Dynamic TP type selected dynamicTp1Taken_L: {self.dynamicTp1Taken_L}")
                if not self.dynamicTp1Taken_L:
                    self.logger.info(f"tp1_qty_long_pct : {self.tp1_qty_long_pct}")
                    if self.tp1_qty_long_pct < 100:
                        # Dynamic TP1 partial exit - fills at close
                        self.exit_long_partial(close, timestamp, self.tp1_qty_long_pct, "Dyn TP1 L")
                        self.dynamicTp1Taken_L = True
                        
                        # TSL activation after dynamic TP1
                        if (self.use_trailing_stop and 
                            self.ts_activation_mode_long == "After Dynamic TP1" and 
                            not self.tsl_active_L):
                            self.tsl_active_L = True
                            actualOffset = self.get_final_tsl_offset()
                            self.trailStopLevel_L = round(high - actualOffset, 2)
                    else:
                        # Dynamic TP full exit
                        self.exit_long(close, timestamp, "Dyn TP Full L")
                        self.dynamicTp1Taken_L = True
                        # Note: Pine Script doesn't reset dir here for full exit
                else:
                    # Dynamic TP2 exit (remainder)
                    self.exit_long(close, timestamp, "Dyn TP2 L (Rem)")
                    # Reset state
                    self.dir = 0
                    self.dynamicTp1Taken_L = False
                    self.percentageTp1Taken_L = False
                    self.trailStopLevel_L = 0.0
                    self.tsl_active_L = False
        
        # Short Dynamic Exit
        if self.positions < 0 and self.dir == -2 and (priceTargetReachedS or delayConditionMetS):
            if self.tp_type_short == "Percentage" and self.percentageTp1Taken_S:
                # Dynamic exit of percentage remainder - fills at close
                self.exit_short(close, timestamp, "Dyn Exit of Pct Rem S")
                # Reset state
                self.dir = 0
                self.dynamicTp1Taken_S = False
                self.percentageTp1Taken_S = False
                self.trailStopLevel_S = 0.0
                self.tsl_active_S = False
                
            elif self.tp_type_short == "Dynamic":
                self.logger.info(f"DynamicTP - Dynamic TP type selected dynamicTp1Taken_L :{self.tp1_qty_short_pct}")
                if not self.dynamicTp1Taken_S:
                    self.logger.info(f"tp1_qty_short_pct : {self.tp1_qty_short_pct}")
                    if self.tp1_qty_short_pct < 100:
                        # Dynamic TP1 partial exit - fills at close
                        self.exit_short_partial(close, timestamp, self.tp1_qty_short_pct, "Dyn TP1 S")
                        self.dynamicTp1Taken_S = True
                        
                        # TSL activation after dynamic TP1
                        if (self.use_trailing_stop and 
                            self.ts_activation_mode_short == "After Dynamic TP1" and 
                            not self.tsl_active_S):
                            self.tsl_active_S = True
                            actualOffset = self.get_final_tsl_offset()
                            self.trailStopLevel_S = round(low + actualOffset, 2)
                    else:
                        # Dynamic TP full exit
                        self.exit_short(close, timestamp, "Dyn TP Full S")
                        self.dynamicTp1Taken_S = True
                        # Note: Pine Script doesn't reset dir here for full exit
                else:
                    # Dynamic TP2 exit (remainder)
                    self.exit_short(close, timestamp, "Dyn TP2 S (Rem)")
                    # Reset state
                    self.dir = 0
                    self.dynamicTp1Taken_S = False
                    self.percentageTp1Taken_S = False
                    self.trailStopLevel_S = 0.0
                    self.tsl_active_S = False

    def _update_trailing_stops_improved(self, high: float, low: float, close: float, timestamp: datetime):
        """Improved Profit Trailing Stop Logic with Signal Control"""
        # Long trailing stop - continuous monitoring
        if self.positions > 0 and self.tsl_active_L:
            actualOffset = self.get_final_tsl_offset()
            currentStopPriceL = round(high - actualOffset, 2)
            self.L_Signal = True
            
            # Update trail stop (only moves up, never down)
            if self.trailStopLevel_L == 0.0 or (currentStopPriceL > self.trailStopLevel_L and self.L_Signal):
                self.trailStopLevel_L = currentStopPriceL
                self.L_Signal = False
            
            # Check for TSL hit - strategy.exit() fills at stop price
            if self.trailStopLevel_L > 0 and low <= self.trailStopLevel_L and self.L_Signal:
                self.exit_long(self.trailStopLevel_L, timestamp, "TSL Long")
                # Note: Pine Script strategy.exit() doesn't reset state here
                # State is reset when position is actually closed
        
        # Short trailing stop - continuous monitoring
        if self.positions < 0 and self.tsl_active_S:
            actualOffset = self.get_final_tsl_offset()
            currentStopPriceS = round(low + actualOffset, 2)
            self.S_Signal = True
            
            # Update trail stop (only moves down, never up)
            if self.trailStopLevel_S == 0.0 or (currentStopPriceS < self.trailStopLevel_S and self.S_Signal):
                self.trailStopLevel_S = currentStopPriceS
                self.S_Signal = False
            
            # Check for TSL hit - strategy.exit() fills at stop price
            if self.trailStopLevel_S > 0 and high >= self.trailStopLevel_S and self.S_Signal:
                self.exit_short(self.trailStopLevel_S, timestamp, "TSL Short")
                # Note: Pine Script strategy.exit() doesn't reset state here


    def _update_trailing_stops_standard(self, high: float, low: float, close: float, timestamp: datetime):
        """Standard Trailing Stop Logic - Consistent 1-bar delay"""
        
        # Store current values
        current_high = high
        current_low = low
        # Store current stop levels for NEXT bar's protection
        self.prev_trailStopLevel_L = self.trailStopLevel_L
        self.prev_trailStopLevel_S = self.trailStopLevel_S
        
        # LONG trailing stop
        if self.positions > 0 and self.tsl_active_L:
            # Calculate NEW stop level for NEXT bar (based on current high)
            actualOffset = self.get_final_tsl_offset()
            next_bar_stop = round(current_high - actualOffset, 2)
            
            # Update trail stop for NEXT bar (only moves up)
            if self.trailStopLevel_L == 0.0 or next_bar_stop > self.trailStopLevel_L:
                self.trailStopLevel_L = next_bar_stop
                self.logger.info(f"🔼 Long Stop Updated: {self.trailStopLevel_L:.2f}")
            
            # Check if CURRENT low hits the PREVIOUS bar's stop level
            if hasattr(self, 'prev_trailStopLevel_L') and self.prev_trailStopLevel_L > 0:
                condition = current_low < self.prev_trailStopLevel_L
                self.logger.info(f"🔍 LONG CHECK - Low: {current_low:.1f} vs Prev Stop: {self.prev_trailStopLevel_L:.1f} = {condition}")
                
                if condition:
                    self.logger.info(f"LONG TSL HIT at {timestamp}")
                    self.exit_long(self.prev_trailStopLevel_L, timestamp, "TSL Long")
        
        # SHORT trailing stop
        if self.positions < 0 and self.tsl_active_S:
            actualOffset = self.get_final_tsl_offset()
            next_bar_stop = round(current_low + actualOffset, 2)
            
            if self.trailStopLevel_S == 0.0 or next_bar_stop < self.trailStopLevel_S:
                self.trailStopLevel_S = next_bar_stop
                self.logger.info(f"🔽 Short Stop Updated: {self.trailStopLevel_S:.2f}")
            
            if hasattr(self, 'prev_trailStopLevel_S') and self.prev_trailStopLevel_S > 0:
                condition = current_high > self.prev_trailStopLevel_S
                self.logger.info(f"🔍 SHORT CHECK - High: {current_high:.1f} vs Prev Stop: {self.prev_trailStopLevel_S:.1f} = {condition}")
                
                if condition:
                    self.logger.info(f"SHORT TSL HIT at {timestamp}")
                    self.exit_short(self.prev_trailStopLevel_S, timestamp, "TSL Short")
        
        

    def update_trailing_stops(self, high: float, low: float, close: float, timestamp: datetime):
            """Trailing Stop Logic - With Profit Improvement Option"""
            if not self.use_trailing_stop:
                return
            
            if self.improve_Profit:
                # Improved Profit Logic with Signal Control
                self._update_trailing_stops_improved(high, low, close, timestamp)
            else:
                # Standard Trailing Stop Logic
                self._update_trailing_stops_standard(high, low, close, timestamp)



    # ========== POSITION MANAGEMENT ==========

    def enter_long(self, price: float, timestamp: datetime):
        """Enter long position"""
        if self.positions < 0:
            self.exit_short(price, timestamp, "Reverse to Long")
        
        self.positions = self.trade_qty
        self.entry_price = price
        self.entry_time = timestamp

    def enter_short(self, price: float, timestamp: datetime):
        """Enter short position"""
        if self.positions > 0:
            self.exit_long(price, timestamp, "Reverse to Short")
        
        self.positions = -self.trade_qty
        self.entry_price = price
        self.entry_time = timestamp

    def exit_long(self, price: float, timestamp: datetime, reason: str):
        """Exit long position"""
        if self.positions <= 0:
            return
            
        pnl = (price - self.entry_price) * self.positions
        self.record_trade("LONG", self.positions, self.entry_price, price, 
                         self.entry_time, timestamp, pnl, reason)
        
        # Reset state (EXACT Pine Script logic)
        self.positions = 0
        self.dir = 0
        self.dynamicTp1Taken_L = False
        self.percentageTp1Taken_L = False
        self.trailStopLevel_L = 0.0
        self.tsl_active_L = False
        
        self.logger.info(f"LONG EXIT: {reason} @ {price:.2f}, PnL: {pnl:.2f}")

    def exit_short(self, price: float, timestamp: datetime, reason: str):
        """Exit short position"""
        if self.positions >= 0:
            return
            
        pnl = (self.entry_price - price) * abs(self.positions)
        self.record_trade("SHORT", abs(self.positions), self.entry_price, price,
                         self.entry_time, timestamp, pnl, reason)
        
        # Reset state (EXACT Pine Script logic)
        self.positions = 0
        self.dir = 0
        self.dynamicTp1Taken_S = False
        self.percentageTp1Taken_S = False
        self.trailStopLevel_S = 0.0
        self.tsl_active_S = False
        
        self.logger.info(f"SHORT EXIT: {reason} @ {price:.2f}, PnL: {pnl:.2f}")

    def exit_long_partial(self, price: float, timestamp: datetime, percent: float, reason: str):
        """Partial long exit"""
        if self.positions <= 0:
            return

        exit_qty = int(self.positions * percent / 100.0)
        exit_qty = max(1, exit_qty)
        
        if exit_qty >= self.positions:
            self.exit_long(price, timestamp, f"{reason} - Full")
            return

        pnl = (price - self.entry_price) * exit_qty
        self.record_trade("LONG", exit_qty, self.entry_price, price,
                         self.entry_time, timestamp, pnl, f"Partial - {reason}")
        
        self.positions -= exit_qty
        self.logger.info(f"LONG PARTIAL EXIT: {exit_qty} units, {self.positions} remain")

    def exit_short_partial(self, price: float, timestamp: datetime, percent: float, reason: str):
        """Partial short exit"""
        if self.positions >= 0:
            return

        current_qty_abs = abs(self.positions)
        exit_qty = int(current_qty_abs * percent / 100.0)
        exit_qty = max(1, exit_qty)
        
        if exit_qty >= current_qty_abs:
            self.exit_short(price, timestamp, f"{reason} - Full")
            return

        pnl = (self.entry_price - price) * exit_qty
        self.record_trade("SHORT", exit_qty, self.entry_price, price,
                         self.entry_time, timestamp, pnl, f"Partial - {reason}")
        
        self.positions += exit_qty
        self.logger.info(f"SHORT PARTIAL EXIT: {exit_qty} units, {abs(self.positions)} remain")

    def record_trade(self, direction: str, quantity: int, entry_price: float, exit_price: float,
                    entry_time: datetime, exit_time: datetime, pnl: float, exit_reason: str):
        """Record trade details"""
        self.trade_counter += 1
        trade = {
            'trade_id': self.trade_counter,
            'direction': direction,
            'quantity': quantity,
            'entry_price': entry_price,
            'exit_price': exit_price,
            'entry_time': entry_time,
            'exit_time': exit_time,
            'pnl': pnl,
            'exit_reason': exit_reason
        }
        self.trades.append(trade)

    # ========== MAIN PROCESSING LOOP ==========

    def check_entries(self, close: float, timestamp: datetime, is_sideways: bool):
        """COMPLETE Pine Script Entry Logic - WITH TRADING CONTROL"""
        
        # ✅ ADD TRADING WINDOW CONTROL
        if self.trading_start_date and timestamp < self.trading_start_date:
            return  # Skip entries before trading start date
        
        if self.trading_end_date and timestamp >= self.trading_end_date:
            return  # Skip entries after trading end date
        
        # ✅ TRADING HOURS CHECK HERE
        if self.trading_schedule_active:
            if not self.is_within_trading_hours(timestamp):
                self.logger.debug(f"⏰ Entry BLOCKED: Outside trading hours - {timestamp}")
                return
        
        # Check if already in position
        if self.positions != 0:
            return
        
        # Trading approval conditions
        longApproval = self.enable_long
        shortApproval = self.enable_short
        okToTrade = not is_sideways if self.use_sideways_filter else True
        
        # Crossover signals (EXACT Pine Script ta.crossover/ta.crossunder)
        long_signal = (self.prev_tsi is not None and 
                    self.prev_tsi <= self.long_threshold and 
                    self.m_tsi > self.long_threshold)          

        short_signal = (self.prev_tsi is not None and 
                        self.prev_tsi >= self.short_threshold and    
                        self.m_tsi < self.short_threshold) 
                
        longCondition = long_signal and longApproval and okToTrade
        shortCondition = short_signal and shortApproval and okToTrade
        
        # Long Entry (EXACT Pine Script logic)
        if longCondition and self.positions <= 0:
            self.execute_long_entry(close, timestamp)
        
        # Short Entry (EXACT Pine Script logic)  
        if shortCondition and self.positions >= 0:
            self.execute_short_entry(close, timestamp)

    def process_bar(self, timestamp: datetime, open_price: float, high: float, low: float, close: float, volume: float = 0):
        """MAIN BAR PROCESSING - EXACT Pine Script Order"""
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=timezone.utc)
        elif timestamp.tzinfo != timezone.utc:
            timestamp = timestamp.astimezone(timezone.utc)
        
        if self.trading_start_date and timestamp < self.trading_start_date:
            return  
        
        if self.trading_end_date and timestamp >= self.trading_end_date:
            return
        
        is_trading_hours = True
        if self.trading_schedule_active:
            is_trading_hours = self.is_within_trading_hours(timestamp)
            self.logger.info(f"⏰ Processing bar at {timestamp} - Trading Hours: {is_trading_hours}")
            
            # if not is_trading_hours:
            #     self.logger.debug(f"⏰ Outside trading hours - updating indicators only")
                
            #     return
    
        # Store price data
        self.high_window.append(high)
        self.low_window.append(low)
        self.close_window.append(close)
        self.open_window.append(open_price)

        

        # Calculate OHLC4 for sideways filter
        ohlc4 = (open_price + high + low + close) / 4.0
        self.side_ohlc4.append(ohlc4)
        
        # Calculate True Range
        prev_close = self.prev_close if self.prev_close is not None else close
        true_range = self.calculate_true_range(high, low, prev_close)
        self.true_ranges.append(true_range)
        
        # Calculate ATR
        self.atrTS = self.calculate_atr()
        custom_atr = self.calculate_custom_atr(high, low, prev_close)
        self.custom_atr_values.append(custom_atr)
        self.m_atr = custom_atr
        self.off = self.get_final_tsl_offset()

        self.logger.info( f"{timestamp} ATR : {self.atrTS} " f"Offset : {self.off}")
        
        # Calculate indicators
        self.calculate_tsi(close)
        is_sideways = self.calculate_sideways_market()
        self.calculate_peak_detection(high, low)
        self.logger.info(f" {timestamp} TSI: {self.m_tsi:.2f}, TSI_MA: {self.m_tsiMA:.2f}, Magenta: {self.magenta}")
    

        current_equity = self.calculate_current_equity(close)
        self.equity_curve.append({
            'timestamp': timestamp,
            'equity': current_equity,
            'price': close
        })

        # Update delay counters
        self.update_delay_counters()
        
        # Increment bar counter
        self.current_bar += 1
        
        # ========== PINE SCRIPT EXECUTION ORDER ==========
        
        # Reset flags when flat (like Pine Script)
        if self.positions == 0 and self.prev_tsi is not None:
            self.dynamicTp1Taken_L = False
            self.dynamicTp1Taken_S = False
            self.percentageTp1Taken_L = False
            self.percentageTp1Taken_S = False
        
        # Check exits first (Pine Script order)
        self.check_exits(high, low, close, timestamp)
        
        # Then check entries (only if no position after exits)
        if self.positions == 0:
            self.check_entries(close, timestamp, is_sideways)
        
        

        # Update previous values for next bar
        self.prev_close = close
        self.prev_high = high
        self.prev_low = low
        self.prev_tsi = self.m_tsi
        self.prev_tsi_ma = self.m_tsiMA

    def calculate_current_equity(self, current_price: float) -> float:
        """Calculate current total equity including unrealized PnL"""
        # Realized PnL from closed trades
        realized_pnl = sum(trade['pnl'] for trade in self.trades)
        
        # Unrealized PnL from current open position
        unrealized_pnl = 0
        if self.positions > 0:  # Long position
            unrealized_pnl = (current_price - self.entry_price) * self.positions
        elif self.positions < 0:  # Short position  
            unrealized_pnl = (self.entry_price - current_price) * abs(self.positions)
        
        return self.initial_cash + realized_pnl + unrealized_pnl

    def calculate_drawdown(self) -> Tuple[float, float, float]:
        """Calculate Max Equity Drawdown including unrealized PnL - FIXED"""
        if not hasattr(self, 'equity_curve') or not self.equity_curve:
            return 0.0, 0.0, self.initial_cash
        
        # Use the real equity curve that includes ALL bars
        equity_values = [point['equity'] for point in self.equity_curve]
        
        peak_equity = equity_values[0]
        max_drawdown_absolute = 0.0
        max_drawdown_pct = 0.0
        
        for equity in equity_values:
            # Update running peak equity
            if equity > peak_equity:
                peak_equity = equity
            
            # Calculate current drawdown from peak
            current_drawdown = peak_equity - equity
            current_drawdown_pct = (current_drawdown / peak_equity) * 100 if peak_equity > 0 else 0
            
            # Update maximum drawdown
            if current_drawdown > max_drawdown_absolute:
                max_drawdown_absolute = current_drawdown
                max_drawdown_pct = current_drawdown_pct
        
        final_equity = equity_values[-1]
        
        
        return max_drawdown_absolute, max_drawdown_pct, final_equity

    def get_performance_report(self) -> Dict:
        """Generate performance report with Max Equity Drawdown"""
        if not self.trades:
            return {
                'max_drawdown': 0.0,
                'max_drawdown_pct': 0.0,
                'final_equity': self.initial_cash,
                'total_trades': 0,
                'total_pnl': 0,
                'win_rate': 0,
                'profit_factor': 0
            }
        
        total_pnl = sum(trade['pnl'] for trade in self.trades)
        winning_trades = [t for t in self.trades if t['pnl'] > 0]
        losing_trades = [t for t in self.trades if t['pnl'] < 0]
        
        win_rate = len(winning_trades) / len(self.trades) * 100 if self.trades else 0
        
        # Calculate profit factor
        gross_profit = sum([t['pnl'] for t in winning_trades]) if winning_trades else 0
        gross_loss = abs(sum([t['pnl'] for t in losing_trades])) if losing_trades else 0
        profit_factor = gross_profit / gross_loss if gross_loss != 0 else float('inf')
        
        # ✅ Use the FIXED Max Equity Drawdown calculation
        max_drawdown, max_drawdown_pct, final_equity = self.calculate_drawdown()
        
        return {
            'total_trades': len(self.trades),
            'winning_trades': len(winning_trades),
            'losing_trades': len(losing_trades),
            'win_rate': win_rate,
            'total_pnl': total_pnl,
            'profit_factor': profit_factor,
            'max_drawdown': max_drawdown,  # Absolute Max Equity Drawdown in currency
            'max_drawdown_pct': max_drawdown_pct,  # Percentage Max Equity Drawdown
            'final_equity': final_equity,
            'initial_capital': self.initial_cash
        }

    def get_strategy_state(self) -> Dict:
        """Get current strategy state for debugging"""
        state = {
            'current_bar': self.current_bar,
            'positions': self.positions,
            'dir': self.dir,
            'm_tsi': self.m_tsi,
            'm_tsiMA': self.m_tsiMA,
            'bs_long': self.bs_long,
            'bs_short': self.bs_short,
            'magenta': self.magenta,
            'longEntry': self.longEntry,
            'shortEntry': self.shortEntry,
            'trailStopLevel_L': self.trailStopLevel_L,
            'trailStopLevel_S': self.trailStopLevel_S,
            'improve_Profit': self.improve_Profit,
            'L_Signal': self.L_Signal,
            'S_Signal': self.S_Signal
        }
    
        if self.trading_schedule_active:
            state['trading_schedule'] = {
                'active': True,
                'current_time_in_schedule': self.is_within_trading_hours(
                    datetime.now(timezone.utc)
                ) if hasattr(self, 'current_bar') and self.current_bar > 0 else False
            }
        
        return state