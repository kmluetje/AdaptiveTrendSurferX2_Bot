# fetch_coinbase.py

import os, sys, time, csv, pathlib, io, json
from datetime import datetime, timedelta, timezone
import threading
from queue import Queue, Empty
import logging

try:
    from coinbase.rest import RESTClient
    from coinbase.websocket import WSClient, WSClientException
except Exception:
    print("coinbase package not installed. Install with: pip install coinbase", file=sys.stderr)
    raise

# ---------- Configuration ----------
def setup_logging():
    """Setup logging with directory creation"""
    # Create log directory with parents
    log_dir = pathlib.Path("logs/downloads")
    log_dir.mkdir(parents=True, exist_ok=True)
    
    # Generate log filename with timestamp
    log_filename = f"download_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    log_filepath = log_dir / log_filename
    
    # Configure logging to both file and console
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_filepath, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    # Log startup information
    logging.info(f"=== Coinbase Data Download Started ===")
    logging.info(f"Log file: {log_filepath}")
    return log_filepath

# Setup logging at module level
log_filepath = setup_logging()

# ---------- Coinbase API Setup ----------
KEY_FILE_BASENAME = "cdp_api_key.json"

def find_key_file():
    """Find the key file in multiple locations - EXE COMPATIBLE"""
    if getattr(sys, 'frozen', False):
        base_dir = getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
    else:
        base_dir = os.path.dirname(__file__)
    
    possible_paths = [
        os.path.join(base_dir, KEY_FILE_BASENAME),
        os.path.join(base_dir, "secrets", KEY_FILE_BASENAME),
        os.path.join(os.path.dirname(base_dir), KEY_FILE_BASENAME),
        os.path.join(os.path.dirname(base_dir), "secrets", KEY_FILE_BASENAME),
        KEY_FILE_BASENAME,
    ]
    
    for path in possible_paths:
        if os.path.isfile(path):
            return path
    return None

def build_rest_client(verbose=False):
    """Initialize Coinbase REST client"""
    key_file_path = find_key_file()
    
    if key_file_path:
        logging.info("Using key file at %s", key_file_path)
        return RESTClient(key_file=key_file_path, verbose=verbose)
    else:
        API_KEY = os.getenv("COINBASE_API_KEY", "organizations/{org_id}/apiKeys/{key_id}")
        API_SECRET = os.getenv("COINBASE_API_SECRET", "-----BEGIN EC PRIVATE KEY-----\nYOUR PRIVATE KEY\n-----END EC PRIVATE KEY-----\n")
        return RESTClient(api_key=API_KEY, api_secret=API_SECRET, verbose=verbose)

def get_api_credentials():
    """Get API credentials for WebSocket"""
    key_file_path = find_key_file()
    if key_file_path:
        with open(key_file_path, "r", encoding="utf-8") as f:
            key_json = json.load(f)
        return key_json.get("name"), key_json.get("privateKey")
    else:
        API_KEY = os.getenv("COINBASE_API_KEY", "organizations/{org_id}/apiKeys/{key_id}")
        API_SECRET = os.getenv("COINBASE_API_SECRET", "-----BEGIN EC PRIVATE KEY-----\nYOUR PRIVATE KEY\n-----END EC PRIVATE KEY-----\n")
        return API_KEY, API_SECRET

def safe_len_candles(resp) -> int:
    """Get number of candles from response"""
    try:
        if hasattr(resp, "candles") and resp.candles is not None:
            return len(resp.candles)
        d = resp.to_dict() if hasattr(resp, "to_dict") else resp
        return len(d.get("candles", [])) if isinstance(d, dict) else 0
    except Exception:
        return 0

# ---------- Helpers ----------
def parse_env_list(name: str, default: str):
    raw = os.getenv(name, default).strip()
    if not raw:
        return []
    return [p.strip() for p in raw.replace(";", ",").split(",") if p.strip()]

def norm_coinbase_symbol(sym: str):
    """Keep symbol as-is for Coinbase API"""
    sym = sym.upper().replace(" ", "")
    lean_ticker = sym.replace('-', '').lower()
    return sym, lean_ticker

def ensure_dir(p: pathlib.Path):
    p.mkdir(parents=True, exist_ok=True)

def ymd(dt_utc: datetime) -> str:
    return dt_utc.strftime("%Y%m%d")

def ms_since_midnight(dt_utc: datetime) -> int:
    """LEAN minute TradeBar time field = milliseconds since midnight (UTC)."""
    return (
        ((dt_utc.hour * 60 + dt_utc.minute) * 60 + dt_utc.second) * 1000
        + dt_utc.microsecond // 1000
    )

def resolution_to_granularity(res: str) -> str:
    """Convert resolution to Coinbase granularity"""
    r = res.lower()
    if r in ("minute", "1min", "m1"): return "ONE_MINUTE"
    if r in ("5min", "m5"): return "FIVE_MINUTE"
    if r in ("15min", "m15"): return "FIFTEEN_MINUTE"
    if r in ("hour", "hr", "h1", "60min"): return "ONE_HOUR"
    if r in ("6hour", "h6"): return "SIX_HOUR"
    if r in ("daily", "day", "1d", "d"): return "ONE_DAY"
    raise ValueError(f"Unsupported RESOLUTION '{res}'. Use Minute/5Min/15Min/Hour/6Hour/Daily.")

def granularity_to_seconds(granularity: str) -> int:
    """Convert Coinbase granularity to seconds"""
    granularity_map = {
        "ONE_MINUTE": 60,
        "FIVE_MINUTE": 300,
        "FIFTEEN_MINUTE": 900,
        "ONE_HOUR": 3600,
        "SIX_HOUR": 21600,
        "ONE_DAY": 86400
    }
    return granularity_map.get(granularity, 60)

# ---------- Writer (CSV only - no ZIP) ----------
def write_lean_day_csv(out_dir: pathlib.Path, day_utc: datetime, rows_utc):
    """Writes <YYYYMMDD>_trade.csv (no header)."""
    ensure_dir(out_dir)
    day_key = ymd(day_utc)
    csv_path = out_dir / f"{day_key}_trade.csv"

    with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
        w = csv.writer(csvfile, lineterminator="\n")
        for dt, o, h, l, c, v in rows_utc:
            w.writerow([ms_since_midnight(dt), f"{o:.8f}", f"{h:.8f}", f"{l:.8f}", f"{c:.8f}", f"{v:.8f}"])

# ---------- Fetcher using Coinbase SDK ----------
def fetch_ohlcv_coinbase(client, symbol: str, granularity: str, start_dt: datetime, end_dt: datetime):
    """Fetch OHLCV data using Coinbase REST API"""
    
    start_ts = str(int(start_dt.timestamp()))
    end_ts = str(int(end_dt.timestamp()))
    
    candles_data = []
    
    try:
        # Try authenticated endpoint first
        logging.info(f"Trying authenticated endpoint for {symbol}...")
        response = client.get_candles(
            product_id=symbol,
            start=start_ts,
            end=end_ts,
            granularity=granularity,
            limit=300
        )
        count = safe_len_candles(response)
        logging.info(f"Fetched {count} candles (auth) for {symbol}")
        candles_data = response.candles if hasattr(response, 'candles') else []
        
    except Exception as e:
        logging.error(f"[REST AUTH ERROR] {e}")
        
        # Fallback to PUBLIC endpoint
        try:
            logging.info(f"Trying public endpoint for {symbol}...")
            response = client.get_public_candles(
                product_id=symbol,
                start=start_ts,
                end=end_ts,
                granularity=granularity,
                limit=300
            )
            count = safe_len_candles(response)
            logging.info(f"Fetched {count} candles (public) for {symbol}")
            candles_data = response.candles if hasattr(response, 'candles') else []
            
        except Exception as e2:
            logging.error(f"[REST PUBLIC ERROR] {e2}")
            return []
    
    # Process candles
    for candle in candles_data:
        if hasattr(candle, 'to_dict'):
            candle = candle.to_dict()
        
        start_ts = int(candle.get('start', 0))
        dt = datetime.fromtimestamp(start_ts, tz=timezone.utc)
        open_price = float(candle.get('open', 0))
        high = float(candle.get('high', 0))
        low = float(candle.get('low', 0))
        close = float(candle.get('close', 0))
        volume = float(candle.get('volume', 0))
        
        yield (dt, open_price, high, low, close, volume)

def fetch_ohlcv_all_coinbase(client, symbol: str, granularity: str, start_dt: datetime, end_dt: datetime):
    """Fetch all OHLCV data with pagination handling"""
    current_start = start_dt
    granularity_seconds = granularity_to_seconds(granularity)
    max_candles_per_request = 300
    
    while current_start < end_dt:
        batch_end = current_start + timedelta(seconds=granularity_seconds * max_candles_per_request)
        batch_end = min(batch_end, end_dt)
        
        logging.info(f"Fetching {symbol} from {current_start} to {batch_end}")
        
        candles = list(fetch_ohlcv_coinbase(client, symbol, granularity, current_start, batch_end))
        
        for candle in candles:
            yield candle
        
        if not candles:
            break
            
        current_start = batch_end + timedelta(seconds=granularity_seconds)
        time.sleep(0.5)

# ---------- Configuration Loading ----------
def load_config(config_path="config.json"):
    """Load configuration from single JSON file"""
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    # Only check for essential fields
    required_fields = [
        "DATA_ROOT", "SYMBOLS", "RESOLUTION", "download_start_date", "download_end_date", "EXCHANGE"
    ]
    
    for field in required_fields:
        if field not in config:
            raise ValueError(f"Missing required configuration field: {field}")
    
    return config

def parse_symbols(symbols_config):
    """Parse symbols from config (string or list) to list"""
    if isinstance(symbols_config, str):
        return [s.strip() for s in symbols_config.split(",") if s.strip()]
    elif isinstance(symbols_config, list):
        return symbols_config
    else:
        return [str(symbols_config)]

def check_historical_data_exists(data_root, symbols, start_dt, end_dt):
    """Check if historical data already exists for the given range"""
    for user_sym in symbols:
        coinbase_symbol, lean_ticker = norm_coinbase_symbol(user_sym)
        data_dir = data_root / "crypto" / "coinbase" / "minute" / lean_ticker
        
        if not data_dir.exists():
            return False
            
        current_dt = start_dt
        while current_dt <= end_dt:
            day_key = ymd(current_dt)
            csv_file = data_dir / f"{day_key}_trade.csv"
            if not csv_file.exists():
                return False
            current_dt += timedelta(days=1)
    
    return True

def main():
    """Main function - SIMPLIFIED (UTC only)"""
    logging.info("=== Starting Coinbase Data Download ===")
    
    config_path = "config.json"
    
    if not os.path.exists(config_path):
        logging.error(f"Config file not found: {config_path}")
        return
    
    try:
        config = load_config(config_path)
        logging.info(f"Configuration loaded successfully from {config_path}")
    except Exception as e:
        logging.error(f"Failed to load configuration: {e}")
        return
    
    # Unpack configuration
    DATA_ROOT = pathlib.Path(config["DATA_ROOT"]).resolve()
    SYMBOLS = parse_symbols(config["SYMBOLS"])
    RES = config["RESOLUTION"]
    FROM = config["download_start_date"]
    TO = config["download_end_date"]
    EXCHANGE = config["EXCHANGE"]

    # Parse dates as UTC (simplified)
    start_dt = datetime.strptime(FROM, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    end_dt = datetime.strptime(TO, "%Y-%m-%d").replace(hour=23, minute=59, second=59, tzinfo=timezone.utc)
    
    # Add date validation to prevent future date errors
    now_utc = datetime.now(timezone.utc)
    logging.info(f"Current UTC time: {now_utc}")
    
    if start_dt > now_utc:
        logging.error(f"Start date {start_dt} is in the future! Current UTC time: {now_utc}")
        logging.error("Please adjust your download_start_date to a past date.")
        return
    
    if end_dt > now_utc:
        logging.warning(f"End date {end_dt} is in the future. Adjusting to current time.")
        end_dt = now_utc.replace(second=0, microsecond=0)
    
    logging.info(f"API range (UTC): FROM={start_dt} TO={end_dt}")
    
    granularity = resolution_to_granularity(RES)

    logging.info(f"DATA_ROOT={DATA_ROOT}")
    logging.info(f"SYMBOLS={SYMBOLS} RESOLUTION={RES} granularity={granularity}")
    logging.info(f"Config dates: start_date={FROM} end_date={TO}")
    logging.info(f"API range (UTC): FROM={start_dt} TO={end_dt}")

    # Initialize Coinbase client
    try:
        client = build_rest_client(verbose=False)
        key_file_path = find_key_file()
        if key_file_path:
            logging.info(f"Coinbase REST client initialized successfully (using: {key_file_path})")
        else:
            logging.info("Coinbase REST client initialized with default credentials")
    except Exception as e:
        logging.error(f"Failed to initialize Coinbase client: {e}")
        return

    # Always fetch historical data
    logging.info("Fetching data from Coinbase...")
    for user_sym in SYMBOLS:
        try:
            coinbase_symbol, lean_ticker = norm_coinbase_symbol(user_sym)
            logging.info(f"{user_sym} -> coinbase:{coinbase_symbol} lean:{lean_ticker}")

            res_dir = RES.lower()
            out_dir = DATA_ROOT / "crypto" / "coinbase" / res_dir / lean_ticker

            day_buffer = {}
            
            # Fetch data using Coinbase API
            fetched_data = list(fetch_ohlcv_all_coinbase(client, coinbase_symbol, granularity, start_dt, end_dt))
            
            if not fetched_data:
                logging.warning(f"No data returned for {coinbase_symbol}.")
                continue

            for dt, o, h, l, c, v in fetched_data:
                k = ymd(dt)
                day_buffer.setdefault(k, []).append((dt, float(o), float(h), float(l), float(c), float(v)))

            if not day_buffer:
                logging.warning(f"No data collected for {coinbase_symbol} in range.")
                continue

            for day_key, rows in sorted(day_buffer.items()):
                rows.sort(key=lambda r: r[0])
                day_dt = datetime.strptime(day_key, "%Y%m%d").replace(tzinfo=timezone.utc)
                write_lean_day_csv(out_dir, day_dt, rows)
                logging.info(f"{coinbase_symbol} {RES} -> {out_dir}/{day_key}_trade.csv  ({len(rows)} rows)")
                
        except Exception as e:
            logging.error(f"Error for {user_sym}: {e}")
            logging.error("Traceback:", exc_info=True)
            continue

    logging.info("=== Coinbase Data Download Completed ===")

if __name__ == "__main__":
    main()