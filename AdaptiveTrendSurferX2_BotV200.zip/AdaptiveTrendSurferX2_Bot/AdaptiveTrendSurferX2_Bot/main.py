# main.py 

import json
import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, timezone
from pathlib import Path
import logging
import os
from AdaptiveTrendSurferX2 import AdaptiveTrendSurferX2

def setup_logging():
    """Setup logging configuration"""
    os.makedirs('logs', exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('logs/live_trading.log', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def load_config(config_path="config.json"):
    """Load configuration from JSON file"""
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
        print("Configuration loaded successfully")
        return config
    except Exception as e:
        print(f"Error loading config: {e}")
        raise

def parse_symbols(symbols_config):
    """Parse symbols from config"""
    if isinstance(symbols_config, str):
        return [s.strip() for s in symbols_config.split(",") if s.strip()]
    elif isinstance(symbols_config, list):
        return symbols_config
    else:
        return [str(symbols_config)]

def resolution_to_granularity(res: str) -> str:
    """Convert resolution to Coinbase granularity"""
    r = res.lower()
    if r in ("minute", "min", "m1"): return "ONE_MINUTE"
    if r in ("5min", "m5"): return "FIVE_MINUTE"
    if r in ("15min", "m15"): return "FIFTEEN_MINUTE"
    if r in ("hour", "hr", "h1", "60min"): return "ONE_HOUR"
    if r in ("6hour", "h6"): return "SIX_HOUR"
    if r in ("daily", "day", "1d", "d"): return "ONE_DAY"
    raise ValueError(f"Unsupported RESOLUTION '{res}'. Use Minute/5Min/15Min/Hour/6Hour/Daily.")

def fetch_ohlcv_coinbase_live(client, symbol: str, granularity: str, start_dt: datetime, end_dt: datetime):
    """Fetch OHLCV data from Coinbase with proper timestamp handling - FIXED"""
    try:
        # Convert to timestamp strings (ensure UTC)
        start_ts = str(int(start_dt.timestamp()))
        end_ts = str(int(end_dt.timestamp()))
        
        print(f"   Fetching {symbol} from {start_dt.strftime('%Y-%m-%d %H:%M:%S UTC')} to {end_dt.strftime('%Y-%m-%d %H:%M:%S UTC')}")
        
        # Get data from Coinbase
        response = client.get_candles(
            product_id=symbol,
            start=start_ts,
            end=end_ts,
            granularity=granularity
        )
        
        # Extract candles
        candles_data = []
        if hasattr(response, 'candles') and response.candles:
            candles_data = response.candles
        elif hasattr(response, 'data') and response.data:
            candles_data = response.data
        
        if not candles_data:
            print(f"   No data returned for {symbol}")
            return []
        
        processed_candles = []
        
        for candle in candles_data:
            # Convert to dict
            if hasattr(candle, 'to_dict'):
                candle_dict = candle.to_dict()
            elif hasattr(candle, '__dict__'):
                candle_dict = candle.__dict__
            else:
                candle_dict = candle
            
            # Extract OHLCV data
            open_price = float(candle_dict.get('open', 0))
            high = float(candle_dict.get('high', 0))
            low = float(candle_dict.get('low', 0))
            close = float(candle_dict.get('close', 0))
            volume = float(candle_dict.get('volume', 0))
            
            # **FIXED: Extract timestamp properly**
            timestamp_sec = int(candle_dict.get('start', 0))
            if timestamp_sec == 0:
                timestamp_sec = int(candle_dict.get('time', 0))
            
            # **FIXED: Convert to UTC datetime - Coinbase timestamps are in UTC**
            candle_dt = datetime.fromtimestamp(timestamp_sec, tz=timezone.utc)
            
            # Skip invalid data
            if open_price <= 0 or high < low or high <= 0 or low <= 0:
                continue
            
            processed_candles.append((candle_dt, open_price, high, low, close, volume))
        
        # Sort by timestamp (oldest first)
        processed_candles.sort(key=lambda x: x[0])
        
        print(f"   ✅ Retrieved {len(processed_candles)} valid candles for {symbol}")
        
        # Debug: Show first and last candle timestamps
        if processed_candles:
            first_dt = processed_candles[0][0]
            last_dt = processed_candles[-1][0]
            print(f"   📅 Data range: {first_dt.strftime('%Y-%m-%d %H:%M:%S UTC')} to {last_dt.strftime('%Y-%m-%d %H:%M:%S UTC')}")
        
        return processed_candles
                
    except Exception as e:
        print(f"   ❌ Error fetching {symbol}: {e}")
        return []

def warmup_strategy_with_historical(strategy, symbol):
    """Warm up strategy with historical data for proper indicator calculation"""
    try:
        print(f"🔥 Warming up strategy for {symbol} with historical data...")
        
        # Try to load recent historical data
        try:
            from fetch_coinbase import build_rest_client
            client = build_rest_client(verbose=False)
            
            # Fetch last 4 hours of data for warm-up
            current_time = datetime.now(timezone.utc)
            fetch_start = current_time - timedelta(hours=4)
            
            warmup_candles = fetch_ohlcv_coinbase_live(
                client, symbol, "ONE_MINUTE", fetch_start, current_time
            )
            
            if warmup_candles and len(warmup_candles) >= 100:
                print(f"   Processing {len(warmup_candles)} warm-up bars...")
                
                for candle in warmup_candles:
                    bar_time, open_price, high, low, close, volume = candle
                    
                    strategy.process_bar(
                        timestamp=bar_time,
                        open_price=open_price,
                        high=high,
                        low=low,
                        close=close,
                        volume=volume
                    )
                
                # FIX: Use the correct attribute names
                tsi_value = strategy.m_tsi
                positions_value = strategy.positions  # Changed from _positions to positions
                
                print(f"   ✅ Warm-up completed - TSI: {tsi_value:.4f}, Position: {positions_value}")
                return True
            else:
                print(f"   ⚠️  Not enough warm-up data: {len(warmup_candles) if warmup_candles else 0} bars")
                return False
                
        except Exception as e:
            print(f"   ⚠️  Warm-up failed: {e}")
            return False
            
    except Exception as e:
        print(f"   ❌ Warm-up error: {e}")
        return False

def initialize_live_strategy(symbol, config):
    """Initialize strategy for live trading"""
    try:
        print(f"🔄 Initializing live strategy for {symbol}...")
        
        # Create config for this symbol
        symbol_config = config.copy()
        symbol_config['symbol'] = symbol.upper()
        
        # Create fresh strategy instance
        strategy = AdaptiveTrendSurferX2(symbol_config)
        
        # Warm up with historical data
        warmup_success = warmup_strategy_with_historical(strategy, symbol)
        
        if not warmup_success:
            print(f"   ⚠️  Proceeding with minimal warm-up for {symbol}")
            # Strategy will initialize with default values
        
        # FIX: Use the correct attribute names
        print(f"   📊 {symbol} Strategy Ready:")
        print(f"      TSI: {strategy.m_tsi:.4f}")
        print(f"      TSI MA: {strategy.m_tsiMA:.4f}")
        print(f"      Position: {strategy.positions}")  # Changed from _positions to positions
        
        return strategy
        
    except Exception as e:
        print(f"❌ Error initializing strategy for {symbol}: {e}")
        return None
    
def save_live_trading_results(strategy, symbol, reason=""):
    """Save live trading results"""
    try:
        os.makedirs('results/live', exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        date_str = datetime.now().strftime("%Y%m%d")
        
        # Save trades
        if hasattr(strategy, 'trades') and strategy.trades:
            trades_df = pd.DataFrame(strategy.trades)
            trades_file = f"results/live/trades_{symbol}_{date_str}.csv"
            
            if os.path.exists(trades_file):
                # Append to existing file
                existing_df = pd.read_csv(trades_file)
                combined_df = pd.concat([existing_df, trades_df]).drop_duplicates(subset=['trade_id'], keep='last')
                combined_df.to_csv(trades_file, index=False)
            else:
                trades_df.to_csv(trades_file, index=False)
            
            print(f"💾 Trades saved for {symbol} ({len(strategy.trades)} total)")
        
        # Save current state
        state_file = f"results/live/state_{symbol}.json"
        state_data = {
            'timestamp': datetime.now().isoformat(),
            'symbol': symbol,
            'positions': strategy.positions,
            'entry_price': getattr(strategy, 'entry_price', 0),
            'cash': getattr(strategy, 'cash', strategy.initial_cash),
            'tsi': getattr(strategy, 'm_tsi', 0),
            'tsi_ma': getattr(strategy, 'm_tsiMA', 0),
            'total_trades': len(strategy.trades) if hasattr(strategy, 'trades') else 0,
            'save_reason': reason
        }
        
        with open(state_file, 'w') as f:
            json.dump(state_data, f, indent=2, default=str)
            
        return True
        
    except Exception as e:
        print(f"❌ Error saving results for {symbol}: {e}")
        return False

def run_live_mode():
    """CORRECTED Live trading mode with proper timezone handling"""
    logger = setup_logging()
    
    try:
        print("🚀 LIVE TRADING MODE - TIMEZONE CORRECTED")
        print("="*50)
        
        # Load configuration
        config = load_config("config.json")
        symbols = parse_symbols(config.get('SYMBOLS', ['BTC-USD']))
        granularity = resolution_to_granularity(config.get('RESOLUTION', 'Minute'))
        check_interval = config.get('LIVE_CHECK_INTERVAL_SECONDS', 60)
        
        print(f"Trading Symbols: {', '.join(symbols)}")
        print(f"Granularity: {granularity}")
        print(f"Check Interval: {check_interval}s")
        
        # Initialize Coinbase client
        try:
            from fetch_coinbase import build_rest_client
            client = build_rest_client(verbose=True)
            print("✅ Coinbase API connection successful")
        except Exception as e:
            print(f"❌ Coinbase API connection failed: {e}")
            return
        
        # Initialize strategies
        strategies = {}
        for symbol in symbols:
            strategy = initialize_live_strategy(symbol, config)
            if strategy:
                strategies[symbol] = strategy
            else:
                print(f"❌ Skipping {symbol} - strategy initialization failed")
        
        if not strategies:
            print("❌ No strategies initialized successfully")
            return
        
        print(f"\n🎯 LIVE TRADING STARTED")
        print(f"   Active Symbols: {', '.join(strategies.keys())}")
        print("   Press Ctrl+C to stop\n")
        
        # Track last processed bars to avoid duplicates
        last_processed = {symbol: None for symbol in strategies.keys()}
        
        while True:
            try:
                current_time = datetime.now(timezone.utc)
                print(f"\n⏰ {current_time.strftime('%Y-%m-%d %H:%M:%S UTC')} - Checking for new data...")
                
                for symbol, strategy in strategies.items():
                    try:
                        # **FIXED: Fetch recent data with proper UTC timing**
                        # Fetch enough data to ensure we get complete bars
                        fetch_start = current_time - timedelta(minutes=15)  # Increased buffer
                        candles = fetch_ohlcv_coinbase_live(
                            client, symbol, granularity, fetch_start, current_time
                        )
                        
                        if not candles:
                            print(f"   📭 No data received for {symbol}")
                            continue
                        
                        # Process each candle (in case we missed some)
                        new_bars_processed = 0
                        for candle in candles:
                            bar_time, open_price, high, low, close, volume = candle
                            
                            # **FIXED: Skip if we already processed this bar (UTC comparison)**
                            if last_processed[symbol] and bar_time <= last_processed[symbol]:
                                continue
                            
                            # **FIXED: Wait for bar to be complete (UTC timing)**
                            # Calculate bar end time based on granularity
                            if granularity == "ONE_MINUTE":
                                bar_end_time = bar_time + timedelta(minutes=1)
                                buffer_seconds = 30  # 30-second buffer for 1-minute bars
                            elif granularity == "FIVE_MINUTE":
                                bar_end_time = bar_time + timedelta(minutes=5)
                                buffer_seconds = 60  # 1-minute buffer for 5-minute bars
                            else:
                                bar_end_time = bar_time + timedelta(minutes=1)
                                buffer_seconds = 30
                            
                            # Only process if current time is after bar end time + buffer
                            if current_time < bar_end_time + timedelta(seconds=buffer_seconds):
                                # print(f"   ⏳ Skipping {symbol} {bar_time.strftime('%H:%M:%S UTC')} - bar not yet complete")
                                continue
                            
                            # Store previous state for signal detection
                            prev_position = strategy.positions
                            prev_tsi = strategy.m_tsi  
                            
                            # **CRITICAL: Process the bar through strategy**
                            print(f"   📊 Processing {symbol} {bar_time.strftime('%H:%M:%S UTC')} - C:{close:.2f}")
                            
                            strategy.process_bar(
                                timestamp=bar_time,
                                open_price=open_price,
                                high=high,
                                low=low,
                                close=close,
                                volume=volume
                            )
                            
                            # Check for trading signals
                            new_position = strategy.positions
                            new_tsi = strategy.m_tsi  
                            
                            # Log position changes
                            if prev_position != new_position:
                                if new_position > 0:
                                    print(f"   🟢 {symbol} LONG ENTRY: {new_position} units @ {close:.2f}")
                                    logger.info(f"LONG ENTRY - {symbol}: {new_position} @ {close:.2f}, TSI: {new_tsi:.4f}")
                                elif new_position < 0:
                                    print(f"   🔴 {symbol} SHORT ENTRY: {abs(new_position)} units @ {close:.2f}")
                                    logger.info(f"SHORT ENTRY - {symbol}: {abs(new_position)} @ {close:.2f}, TSI: {new_tsi:.4f}")
                                elif new_position == 0 and prev_position != 0:
                                    print(f"   🟡 {symbol} POSITION CLOSED @ {close:.2f}")
                                    logger.info(f"POSITION CLOSED - {symbol} @ {close:.2f}")
                                
                                # Save results on position change
                                save_live_trading_results(strategy, symbol, "position_change")
                            
                            # Log TSI crossovers
                            if (prev_tsi is not None and 
                                ((prev_tsi < 0 and new_tsi >= 0) or (prev_tsi >= 0 and new_tsi < 0))):
                                print(f"   📈 {symbol} TSI Zero Cross: {prev_tsi:.4f} -> {new_tsi:.4f}")
                            
                            # Update last processed time
                            last_processed[symbol] = bar_time
                            new_bars_processed += 1
                        
                        if new_bars_processed > 0:
                            print(f"   ✅ {symbol}: Processed {new_bars_processed} new bars, TSI: {strategy.m_tsi:.4f}, Position: {strategy.positions}")
                        else:
                            print(f"   🔄 {symbol}: No new bars, TSI: {strategy.m_tsi:.4f}, Position: {strategy.positions}")
                            
                    except Exception as e:
                        print(f"   ❌ Error processing {symbol}: {e}")
                        logger.error(f"Error processing {symbol}: {e}")
                        continue
                
                # Wait for next check
                print(f"   ⏳ Waiting {check_interval} seconds...")
                time.sleep(check_interval)
                
            except KeyboardInterrupt:
                print("\n🛑 Live trading stopped by user")
                break
            except Exception as e:
                print(f"❌ Live trading error: {e}")
                logger.error(f"Live trading error: {e}")
                time.sleep(check_interval)
        
        # Save final state
        print("\n💾 Saving final strategy states...")
        for symbol, strategy in strategies.items():
            save_live_trading_results(strategy, symbol, "shutdown")
        
        print("✅ Live trading session ended")
        
    except Exception as e:
        print(f"💥 Fatal error in live mode: {e}")
        logger.error(f"Fatal error in live mode: {e}")

def format_symbol_for_path(symbol):
    """Convert symbol for file paths"""
    return symbol.replace('-', '').replace('_', '').lower()

def show_data():
    """Show available data files"""
    try:
        base_path = "data/crypto"
        base_dir = Path(base_path)
        
        if not base_dir.exists():
            print(f"📁 No data directory found: {base_path}")
            print("   Please download data first using option 4.")
            input("Press Enter to return to main menu...")
            return
        
        print("📊 AVAILABLE DATA FILES")
        print("=" * 50)
        
        data_found = False
        
        for exchange in base_dir.iterdir():
            if exchange.is_dir():
                print(f"\n🏢 Exchange: {exchange.name}")
                
                for data_type in exchange.iterdir():
                    if data_type.is_dir():
                        print(f"  📈 Data Type: {data_type.name}")
                        
                        for symbol_dir in data_type.iterdir():
                            if symbol_dir.is_dir():
                                csv_files = list(symbol_dir.glob("*.csv"))
                                if csv_files:
                                    symbol_display = symbol_dir.name.upper()
                                    if len(symbol_display) == 6:
                                        symbol_display = f"{symbol_display[:3]}-{symbol_display[3:]}"
                                    print(f"    💰 Symbol: {symbol_display}")
                                    print(f"      📄 Files: {len(csv_files)}")
                                    # Show first 3 files as sample
                                    for csv_file in sorted(csv_files)[:3]:
                                        file_date = csv_file.name.split('_')[0]
                                        print(f"        - {file_date} ({csv_file.name})")
                                    if len(csv_files) > 3:
                                        print(f"        ... and {len(csv_files) - 3} more files")
                                    data_found = True
        
        if not data_found:
            print("❌ No data files found. Please download data first.")
        else:
            print(f"\n✅ Data exploration completed.")
        
        input("\nPress Enter to return to main menu...")
        
    except Exception as e:
        print(f"❌ Error exploring data: {e}")
        input("Press Enter to return to main menu...")

def download_data():
    """Download missing data"""
    try:
        config = load_config("config.json")
        symbols = parse_symbols(config.get('SYMBOLS', ['BTC-USD']))
        
        print("DOWNLOADING HISTORICAL DATA")
        print("="*50)
        print(f"Symbols: {', '.join(symbols)}")
        print(f"Date Range: {config.get('start_date')} to {config.get('end_date')}")
        print("This may take a few minutes...")
        print("="*50)
        
        # Import and run fetch_coinbase directly
        try:
            from fetch_coinbase import main as fetch_main
            print("Starting data download...")
            fetch_main()
            print("Data download completed successfully!")
        except Exception as e:
            print(f"Error downloading data: {e}")
            print("Please check your internet connection and Coinbase API access.")
        
        input("Press Enter to return to main menu...")
        
    except Exception as e:
        print(f"Error in download process: {e}")
        input("Press Enter to return to main menu...")

def ensure_data_available(symbols, data_type="minute", exchange="coinbase"):
    """Auto-download missing data before backtest"""
    print("Checking data availability for backtest...")
    
    # Simple check if data exists
    missing_data = False
    for symbol in symbols:
        path_symbol = format_symbol_for_path(symbol)
        data_path = Path("data/crypto") / exchange / data_type / path_symbol
        
        if not data_path.exists():
            print(f"No data directory for {symbol}")
            missing_data = True
            continue
            
        csv_files = list(data_path.glob("*.csv"))
        if not csv_files:
            print(f"No CSV files for {symbol}")
            missing_data = True
        else:
            print(f"{symbol}: {len(csv_files)} files found")
    
    # Auto-download if data is missing
    if missing_data:
        print("Auto-downloading missing data for backtest...")
        try:
            from fetch_coinbase import main as fetch_main
            fetch_main()
            print("Auto-download completed!")
            
            # Verify download worked
            print("Verifying download...")
            download_ok = True
            for symbol in symbols:
                path_symbol = format_symbol_for_path(symbol)
                data_path = Path("data/crypto") / exchange / data_type / path_symbol
                csv_files = list(data_path.glob("*.csv"))
                
                if csv_files:
                    print(f"{symbol}: {len(csv_files)} files available")
                else:
                    print(f"{symbol}: Still no data")
                    download_ok = False
            
            return download_ok
            
        except Exception as e:
            print(f"Auto-download failed: {e}")
            return False
    else:
        print("All data available for backtest!")
        return True

def check_data_availability(symbol, data_type="minute", exchange="coinbase", base_path="data/crypto"):
    """Check if data exists for the given symbol"""
    path_symbol = format_symbol_for_path(symbol)
    data_path = Path(base_path) / exchange / data_type / path_symbol
    
    if not data_path.exists():
        return False, ["No data directory found"]
    
    csv_files = list(data_path.glob("*.csv"))
    if not csv_files:
        return False, ["No CSV files found"]
    
    return True, []

def run_backtest_mode():
    """Backtest Mode - Load ALL data but trade only in date range"""
    try:
        print("BACKTEST MODE")
        print("="*50)
        
        config = load_config("config.json")
        symbols = parse_symbols(config.get('SYMBOLS', ['BTC-USD']))
        data_type = config.get("RESOLUTION")
        exchange = "coinbase"
        
        # Get date range from config
        start_date = config.get('start_date')  # "2025-11-03"
        end_date = config.get('end_date')      # "2025-11-07"
        
        print(f"Symbols: {', '.join(symbols)}")
        print(f"Trading Window: {start_date} to {end_date}")
        print(f"Data Loading: ALL available data (for indicator continuity)")
        print(f"Resolution: {config.get('RESOLUTION', 'Minute')}")
        print("="*50)
        
        # ✅ FIXED: Call ensure_data_available for auto-download
        if not ensure_data_available(symbols, data_type, exchange):
            print("Cannot proceed without data")
            input("Press Enter to return to main menu...")
            return
        
        # Run backtest for each symbol
        for symbol in symbols:
            print(f"Backtesting {symbol}...")
            backtest_logger = setup_backtest_logging(symbol)
            backtest_logger.info(f"Starting backtest for {symbol}")
            backtest_logger.info(f"Trading Window: {start_date} to {end_date}")
            try:
                # ✅ FIXED: Load ALL data for indicator continuity
                print("📥 Loading ALL available data for proper indicator calculation...")
                raw_data = load_crypto_data(symbol, data_type, exchange)
                data = standardize_crypto_data(raw_data, symbol)
                
                if data.empty:
                    print(f"No valid data for {symbol}")
                    continue
                
                # Create strategy with trading window
                symbol_config = config.copy()
                symbol_config['symbol'] = symbol.upper()
                symbol_config['start_date'] = start_date  # Pass start_date to strategy
                symbol_config['end_date'] = end_date      # Pass end_date to strategy
                
                strategy = AdaptiveTrendSurferX2(symbol_config)
                strategy.logger = backtest_logger
                # Run backtest
                print(f"Running backtest on {len(data)} bars...")
                print(f"   Trading window: {start_date} to {end_date}")
                success = run_backtest_with_data(strategy, data, backtest_logger)
                
                if success:
                    report = save_backtest_results(strategy, symbol_config)
                    print_performance_report(report, symbol_config)
                    
                    # ✅ ADD THIS: Log performance results
                    if backtest_logger and report:
                        backtest_logger.info("=== BACKTEST RESULTS ===")
                        backtest_logger.info(f"Total Trades: {report.get('total_trades', 0)}")
                        backtest_logger.info(f"Total PnL: ${report.get('total_pnl', 0):,.2f}")
                        backtest_logger.info(f"Max Drawdown: ${report.get('max_drawdown', 0):,.2f} ({report.get('max_drawdown_pct', 0):.2f}%)")
                        backtest_logger.info(f"Win Rate: {report.get('win_rate', 0):.2f}%")
                else:
                    print("Backtest failed")
                    if backtest_logger:
                        backtest_logger.error("Backtest failed")
                    
            except Exception as e:
                print(f"Error backtesting {symbol}: {e}")
        
        print("Backtest completed for all symbols")
        input("Press Enter to return to main menu...")
        
    except Exception as e:
        print(f"Error in backtest mode: {e}")
        input("Press Enter to return to main menu...")

# Backtest helper functions
def load_crypto_data(symbol, data_type="minute", exchange="coinbase", base_path="data/crypto"):
    """Load ALL cryptocurrency data for indicator continuity"""
    path_symbol = format_symbol_for_path(symbol)
    data_path = Path(base_path) / exchange / data_type / path_symbol
    
    if not data_path.exists():
        raise FileNotFoundError(f"Data path not found: {data_path}")
    
    # Get ALL CSV files
    all_csv_files = list(data_path.glob("*.csv"))
    if not all_csv_files:
        raise FileNotFoundError(f"No CSV files found in: {data_path}")
    
    print(f"📥 Loading ALL {len(all_csv_files)} data files for {symbol} (indicator continuity)")
    
    all_data = []
    for csv_file in sorted(all_csv_files):
        try:
            df = pd.read_csv(csv_file, header=None)
            df.columns = ['time', 'open', 'high', 'low', 'close', 'volume']
            
            # Extract date from filename (format: YYYYMMDD_trade.csv)
            filename = csv_file.stem
            file_date_str = filename.split('_')[0]
            file_datetime = datetime.strptime(file_date_str, "%Y%m%d")
            
            # ✅ FIX: Add UTC timezone to make it timezone-aware
            from datetime import timezone
            file_datetime = file_datetime.replace(tzinfo=timezone.utc)
            
            # Convert milliseconds to timedelta and create timestamp
            df['timestamp'] = df['time'].apply(lambda ms: file_datetime + timedelta(milliseconds=ms))
            
            all_data.append(df)
            print(f"   ✅ Loaded {csv_file.name}")
            
        except Exception as e:
            print(f"⚠️ Error reading {csv_file}: {e}")
            continue
    
    if not all_data:
        raise ValueError("No data could be loaded from CSV files")
    
    combined_df = pd.concat(all_data, ignore_index=True)
    combined_df = combined_df.sort_values('timestamp').reset_index(drop=True)
    
    # Show loaded date range
    if not combined_df.empty:
        actual_start = combined_df['timestamp'].min()
        actual_end = combined_df['timestamp'].max()
        print(f"✅ Loaded {len(combined_df)} bars for {symbol}")
        print(f"   Data range: {actual_start} to {actual_end}")
    
    return combined_df

def standardize_crypto_data(df, symbol):
    """Standardize the data format"""
    df_clean = df.copy()
    
    for col in ['open', 'high', 'low', 'close', 'volume']:
        if col in df_clean.columns:
            df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')
    
    required_columns = ['timestamp', 'open', 'high', 'low', 'close']
    df_clean = df_clean.dropna(subset=required_columns)
    df_clean = df_clean.sort_values('timestamp').reset_index(drop=True)
    df_clean['symbol'] = symbol.upper()
    
    print(f"✅ Standardized {len(df_clean)} bars for {symbol}")
    return df_clean

def run_backtest_with_data(strategy, data, backtest_logger=None):
    """Run backtest with provided data - with trading window tracking"""
    try:
        processed_bars = 0
        total_bars = len(data)
        
        # Track trading window stats
        bars_before_trading = 0
        bars_during_trading = 0
        bars_after_trading = 0
        
        # Get trading window from strategy
        start_date = getattr(strategy, 'trading_start_date', None)
        end_date = getattr(strategy, 'trading_end_date', None)
        
        print(f"🔧 Processing all {total_bars} bars for indicators...")
        if backtest_logger:
            backtest_logger.info(f"Processing all {total_bars} bars for indicators")
        
        if start_date:
            print(f"🎯 Trading starts from: {start_date}")
            if backtest_logger:
                backtest_logger.info(f"Trading starts from: {start_date}")
        if end_date:
            print(f"🎯 Trading ends at: {end_date}")
            if backtest_logger:
                backtest_logger.info(f"Trading ends at: {end_date}")
        
        for _, row in data.iterrows():
            timestamp = row['timestamp']
            open_price = float(row['open'])
            high = float(row['high'])
            low = float(row['low'])
            close = float(row['close'])
            volume = float(row.get('volume', 0))
            
            # Track bars for reporting
            if start_date and timestamp < start_date:
                bars_before_trading += 1
            elif end_date and timestamp >= end_date:
                bars_after_trading += 1
            else:
                bars_during_trading += 1
            
            # Process bar through strategy (ALWAYS process for indicators)
            strategy.process_bar(
                timestamp=timestamp,
                open_price=open_price,
                high=high,
                low=low,
                close=close,
                volume=volume
            )
            
            processed_bars += 1
            
            if processed_bars % 1000 == 0:
                progress = (processed_bars / total_bars) * 100
                status = "WARM-UP" if start_date and timestamp < start_date else "TRADING" if not end_date or timestamp < end_date else "COOL-DOWN"
                progress_msg = f"Progress: {processed_bars}/{total_bars} bars ({progress:.1f}%) - {status}"
                print(f"   📊 {progress_msg}")
                if backtest_logger:
                    backtest_logger.info(progress_msg)
        
        # Final summary
        summary_msg = f"Backtest completed - Warm-up: {bars_before_trading}, Trading: {bars_during_trading}, Cool-down: {bars_after_trading}, Trades: {len(strategy.trades) if hasattr(strategy, 'trades') else 0}"
        print(f"✅ {summary_msg}")
        if backtest_logger:
            backtest_logger.info(summary_msg)
        
        return True
        
    except Exception as e:
        error_msg = f"Backtest failed: {e}"
        print(f"❌ {error_msg}")
        if backtest_logger:
            backtest_logger.error(error_msg)
        return False

def setup_backtest_logging(symbol):
    """Setup logging configuration for backtest - saves to file"""
    os.makedirs('logs/backtest', exist_ok=True)
    
    # Create a separate logger for each symbol
    logger = logging.getLogger(f'backtest_{symbol}')
    logger.setLevel(logging.INFO)
    
    # Remove existing handlers to avoid duplicates
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # Create file handler
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = f'logs/backtest/backtest_{symbol}_{timestamp}.log'
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    
    # Create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    
    # Add handler to logger
    logger.addHandler(file_handler)
    
    print(f"📝 Backtest logs will be saved to: {log_file}")
    return logger

def save_backtest_results(strategy, config):
    """Save backtest results"""
    try:
        os.makedirs('results/backtest', exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        symbol = config.get('symbol', 'Unknown')
        
        # Save trades
        if hasattr(strategy, 'trades') and strategy.trades:
            trades_df = pd.DataFrame(strategy.trades)
            trades_file = f"results/backtest/trades_{symbol}_{timestamp}.csv"
            trades_df.to_csv(trades_file, index=False)
            print(f"💾 Trades saved: {trades_file}")
        
        # Get performance report
        report = strategy.get_performance_report()
        
        # Save summary
        summary = {
            'backtest_timestamp': timestamp,
            'symbol': symbol,
            'performance_report': report
        }
        
        summary_file = f"results/backtest/summary_{symbol}_{timestamp}.json"
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=2, default=str)
        print(f"💾 Summary saved: {summary_file}")
        
        return report
        
    except Exception as e:
        print(f"❌ Error saving results: {e}")
        return None

def print_performance_report(report, config):
    """Print performance report - FIXED for Max Equity Drawdown"""
    print("\n" + "="*60)
    print("📈 PERFORMANCE REPORT")
    print("="*60)
    
    if report:
        print(f"Symbol: {config.get('symbol', 'Unknown')}")
        print(f"Initial Capital: ${config.get('initial_cash', 0):,.2f}")
        print(f"Trading Window: {config.get('start_date', 'All data')} to {config.get('end_date', 'Present')}")
        print()
        print(f"Total Trades: {report.get('total_trades', 0)}")
        print(f"Winning Trades: {report.get('winning_trades', 0)}")
        print(f"Losing Trades: {report.get('losing_trades', 0)}")
        print(f"Win Rate: {report.get('win_rate', 0):.2f}%")
        print(f"Total PnL: ${report.get('total_pnl', 0):,.2f}")
        print(f"Final Equity: ${report.get('final_equity', 0):,.2f}")
        # ✅ FIXED: Show Max Equity Drawdown (absolute and percentage)
        print(f"Max Equity Drawdown: ${report.get('max_drawdown', 0):,.2f} ({report.get('max_drawdown_pct', 0):.2f}%)")
        print(f"Profit Factor: {report.get('profit_factor', 0):.2f}")
    else:
        print("No trades executed during backtest period")
    
    print("="*60)

def main():
    """Main function with 5 options as requested"""
    print("ADAPTIVE TREND SURFER X2 TRADING SYSTEM")
    print("="*50)
    
    while True:
        try:
            print("\nMAIN MENU:")
            print("1. Live Trading")
            print("2. Backtest") 
            print("3. Show Data")
            print("4. Download Data")
            print("5. Exit")
            
            choice = input("\nSelect option (1-5): ").strip()
            
            if choice == "1":
                run_live_mode()
            elif choice == "2":
                run_backtest_mode()
            elif choice == "3":
                show_data()
            elif choice == "4":
                download_data()
            elif choice == "5":
                break
            else:
                print("❌ Invalid choice! Please select 1-5.")
                
        except Exception as e:
            print(f"❌ System error: {e}")
    
    input("Press Enter to close...")

if __name__ == "__main__":
    main()